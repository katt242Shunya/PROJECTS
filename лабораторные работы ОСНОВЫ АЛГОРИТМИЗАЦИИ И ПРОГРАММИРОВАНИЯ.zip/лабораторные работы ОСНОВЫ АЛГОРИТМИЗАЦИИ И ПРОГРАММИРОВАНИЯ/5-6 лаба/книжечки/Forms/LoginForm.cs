using книжечки.Data;
using книжечки.Forms;
using книжечки.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using книжечки.Models;

namespace книжечки
{
    public partial class LoginForm : Form
    {
        private void LoginForm_Load(object sender, EventArgs e)
        {
        }

        public LoginForm()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string loginOrEmail = textBoxLoginOrEmail.Text.Trim();
            string password = textBoxPassword.Text;

            if (string.IsNullOrWhiteSpace(loginOrEmail) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин/email и пароль.");
                return;
            }

            string passwordHash = PasswordHelper.GetHashString(password);

            using (var context = new AppDbContext())
            {
                var user = context.Users.FirstOrDefault(u =>
                    (u.Login == loginOrEmail || u.Email == loginOrEmail) &&
                    u.PasswordHash == passwordHash);

                if (user != null)
                {
                    MessageBox.Show($"Добро пожаловать, {user.Login}!", "Успешный вход", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();

                    if (user.Role == "Admin")
                    {
                        var adminForm = new AdminForm(user);
                        adminForm.ShowDialog();
                    }
                    else
                    {
                        var userForm = new UserForm(user);
                        userForm.ShowDialog();
                    }

                    this.Show();
                }
                else
                {
                    MessageBox.Show("Неверный логин/email или пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            var regForm = new RegistrationForm();
            regForm.ShowDialog();
        }

        private void buttonRecoverPassword_Click(object sender, EventArgs e)
        {
            var recoveryForm = new PasswordRecoveryForm();
            recoveryForm.ShowDialog();
        }
    }
}
