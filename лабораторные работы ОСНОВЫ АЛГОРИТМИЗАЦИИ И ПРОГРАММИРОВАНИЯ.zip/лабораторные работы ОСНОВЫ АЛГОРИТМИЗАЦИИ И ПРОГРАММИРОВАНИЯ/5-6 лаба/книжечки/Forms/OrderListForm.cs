﻿using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using книжечки.Data;
using книжечки.Models;

namespace книжечки.Forms
{
    public partial class OrderListForm : Form
    {
        private readonly User _user;
        private readonly AppDbContext _context = new();

        public OrderListForm(User user)
        {
            InitializeComponent();
            _user = user;
            LoadOrders();
        }

        private void LoadOrders()
        {
            var orders = _context.Orders
                .Include(o => o.Items)
                    .ThenInclude(i => i.Book)
                .Where(o => o.UserId == _user.Id)
                .ToList();

            dataGridViewOrders.DataSource = orders
                .Select(o => new
                {
                    Номер = o.Id,
                    Дата = o.OrderDate,
                    КоличествоКниг = o.Items.Count,
                    Сумма = o.Items.Sum(i => i.Book.Price * i.Quantity)
                })
                .ToList();
        }






    }
}
