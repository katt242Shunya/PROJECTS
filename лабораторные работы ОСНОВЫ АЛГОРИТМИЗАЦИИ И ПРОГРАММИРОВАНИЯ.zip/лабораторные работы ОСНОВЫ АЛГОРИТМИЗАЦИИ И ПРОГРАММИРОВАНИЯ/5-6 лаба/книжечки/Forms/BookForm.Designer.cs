﻿namespace книжечки.Forms
{
    partial class BookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxTitle = new TextBox();
            textBoxAuthor = new TextBox();
            label2 = new Label();
            label3 = new Label();
            numericUpDownYear = new NumericUpDown();
            numericUpDownPrice = new NumericUpDown();
            label4 = new Label();
            buttonSave = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDownYear).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownPrice).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F);
            label1.Location = new Point(204, 79);
            label1.Name = "label1";
            label1.Size = new Size(124, 20);
            label1.TabIndex = 0;
            label1.Text = "Название книги";
            // 
            // textBoxTitle
            // 
            textBoxTitle.Font = new Font("Century Gothic", 9F);
            textBoxTitle.Location = new Point(434, 76);
            textBoxTitle.Name = "textBoxTitle";
            textBoxTitle.Size = new Size(490, 26);
            textBoxTitle.TabIndex = 1;
            // 
            // textBoxAuthor
            // 
            textBoxAuthor.Font = new Font("Century Gothic", 9F);
            textBoxAuthor.Location = new Point(434, 124);
            textBoxAuthor.Name = "textBoxAuthor";
            textBoxAuthor.Size = new Size(490, 26);
            textBoxAuthor.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 9F);
            label2.Location = new Point(204, 124);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 2;
            label2.Text = "Автор";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 9F);
            label3.Location = new Point(204, 172);
            label3.Name = "label3";
            label3.Size = new Size(101, 20);
            label3.TabIndex = 4;
            label3.Text = "Год выпуска";
            // 
            // numericUpDownYear
            // 
            numericUpDownYear.Font = new Font("Century Gothic", 9F);
            numericUpDownYear.Location = new Point(434, 170);
            numericUpDownYear.Name = "numericUpDownYear";
            numericUpDownYear.Size = new Size(125, 26);
            numericUpDownYear.TabIndex = 5;
            // 
            // numericUpDownPrice
            // 
            numericUpDownPrice.Font = new Font("Century Gothic", 9F);
            numericUpDownPrice.Location = new Point(434, 213);
            numericUpDownPrice.Name = "numericUpDownPrice";
            numericUpDownPrice.Size = new Size(150, 26);
            numericUpDownPrice.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 9F);
            label4.Location = new Point(204, 215);
            label4.Name = "label4";
            label4.Size = new Size(49, 20);
            label4.TabIndex = 6;
            label4.Text = "Цена";
            // 
            // buttonSave
            // 
            buttonSave.Font = new Font("Century Gothic", 9F);
            buttonSave.Location = new Point(387, 297);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(232, 78);
            buttonSave.TabIndex = 8;
            buttonSave.Text = "Сохранить!";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // BookForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(1001, 583);
            Controls.Add(buttonSave);
            Controls.Add(numericUpDownPrice);
            Controls.Add(label4);
            Controls.Add(numericUpDownYear);
            Controls.Add(label3);
            Controls.Add(textBoxAuthor);
            Controls.Add(label2);
            Controls.Add(textBoxTitle);
            Controls.Add(label1);
            Name = "BookForm";
            Text = "BookForm";
            ((System.ComponentModel.ISupportInitialize)numericUpDownYear).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownPrice).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxTitle;
        private TextBox textBoxAuthor;
        private Label label2;
        private Label label3;
        private NumericUpDown numericUpDownYear;
        private NumericUpDown numericUpDownPrice;
        private Label label4;
        private Button buttonSave;
    }
}