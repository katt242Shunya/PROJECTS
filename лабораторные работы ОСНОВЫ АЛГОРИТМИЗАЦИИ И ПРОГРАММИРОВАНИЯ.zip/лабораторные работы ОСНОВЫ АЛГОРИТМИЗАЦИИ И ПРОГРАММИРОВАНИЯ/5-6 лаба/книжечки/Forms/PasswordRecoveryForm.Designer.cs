﻿namespace книжечки.Forms
{
    partial class PasswordRecoveryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxEmail = new TextBox();
            textBoxCode = new TextBox();
            label2 = new Label();
            textBoxNewPassword = new TextBox();
            label3 = new Label();
            buttonSendCode = new Button();
            buttonResetPassword = new Button();
            label4 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F);
            label1.Location = new Point(271, 137);
            label1.Name = "label1";
            label1.Size = new Size(271, 20);
            label1.TabIndex = 0;
            label1.Text = "Введите адрес электронной почты";
            // 
            // textBoxEmail
            // 
            textBoxEmail.Font = new Font("Century Gothic", 9F);
            textBoxEmail.Location = new Point(280, 160);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(230, 26);
            textBoxEmail.TabIndex = 1;
            // 
            // textBoxCode
            // 
            textBoxCode.Font = new Font("Century Gothic", 9F);
            textBoxCode.Location = new Point(280, 262);
            textBoxCode.Name = "textBoxCode";
            textBoxCode.Size = new Size(203, 26);
            textBoxCode.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Enabled = false;
            label2.Font = new Font("Century Gothic", 9F);
            label2.Location = new Point(271, 239);
            label2.Name = "label2";
            label2.Size = new Size(100, 20);
            label2.TabIndex = 2;
            label2.Text = "Введите код";
            // 
            // textBoxNewPassword
            // 
            textBoxNewPassword.Font = new Font("Century Gothic", 9F);
            textBoxNewPassword.Location = new Point(280, 349);
            textBoxNewPassword.Name = "textBoxNewPassword";
            textBoxNewPassword.Size = new Size(203, 26);
            textBoxNewPassword.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 9F);
            label3.Location = new Point(271, 326);
            label3.Name = "label3";
            label3.Size = new Size(176, 20);
            label3.TabIndex = 4;
            label3.Text = "Введите новый пароль";
            // 
            // buttonSendCode
            // 
            buttonSendCode.Font = new Font("Century Gothic", 7.20000029F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonSendCode.Location = new Point(389, 192);
            buttonSendCode.Name = "buttonSendCode";
            buttonSendCode.Size = new Size(121, 23);
            buttonSendCode.TabIndex = 6;
            buttonSendCode.Text = "Отправить код";
            buttonSendCode.UseVisualStyleBackColor = true;
            buttonSendCode.Click += buttonSendCode_Click;
            // 
            // buttonResetPassword
            // 
            buttonResetPassword.Font = new Font("Century Gothic", 9F);
            buttonResetPassword.Location = new Point(369, 422);
            buttonResetPassword.Name = "buttonResetPassword";
            buttonResetPassword.Size = new Size(300, 48);
            buttonResetPassword.TabIndex = 7;
            buttonResetPassword.Text = "Сменить пароль";
            buttonResetPassword.UseVisualStyleBackColor = true;
            buttonResetPassword.Click += buttonResetPassword_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(304, 51);
            label4.Name = "label4";
            label4.Size = new Size(439, 40);
            label4.TabIndex = 8;
            label4.Text = "Восстановление пароля";
            // 
            // PasswordRecoveryForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Thistle;
            ClientSize = new Size(1001, 583);
            Controls.Add(label4);
            Controls.Add(buttonResetPassword);
            Controls.Add(buttonSendCode);
            Controls.Add(textBoxNewPassword);
            Controls.Add(label3);
            Controls.Add(textBoxCode);
            Controls.Add(label2);
            Controls.Add(textBoxEmail);
            Controls.Add(label1);
            Name = "PasswordRecoveryForm";
            Text = "PasswordRecoveryForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxEmail;
        private TextBox textBoxCode;
        private Label label2;
        private TextBox textBoxNewPassword;
        private Label label3;
        private Button buttonSendCode;
        private Button buttonResetPassword;
        private Label label4;
    }
}