﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using книжечки.Data;
using книжечки.Utils;

namespace книжечки.Forms
{
    public partial class PasswordRecoveryForm : Form
    {
        private string generatedCode = "";
        private string targetEmail = "";

        public PasswordRecoveryForm()
        {
            InitializeComponent();
        }

        private void buttonSendCode_Click(object sender, EventArgs e)
        {
            string email = textBoxEmail.Text.Trim();

            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Введите корректный email.");
                return;
            }

            using (var context = new AppDbContext())
            {
                var user = context.Users.FirstOrDefault(u => u.Email == email);

                if (user == null)
                {
                    MessageBox.Show("Пользователь с таким email не найден.");
                    return;
                }

                generatedCode = new Random().Next(100000, 999952).ToString();
                targetEmail = email;

                try
                {
                    EmailSender.SendCode(email, generatedCode);
                    MessageBox.Show("Код отправлен на email!");

                    textBoxCode.Enabled = true;
                    textBoxNewPassword.Enabled = true;
                    buttonResetPassword.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при отправке письма: " + ex.Message);
                }
            }
        }

        private void buttonResetPassword_Click(object sender, EventArgs e)
        {
            if (textBoxCode.Text != generatedCode)
            {
                MessageBox.Show("Неверный код.");
                return;
            }

            if (textBoxNewPassword.Text.Length < 8)
            {
                MessageBox.Show("Пароль должен быть не менее 8 символов.");
                return;
            }

            using (var context = new AppDbContext())
            {
                var user = context.Users.FirstOrDefault(u => u.Email == targetEmail);

                if (user != null)
                {
                    user.PasswordHash = PasswordHelper.GetHashString(textBoxNewPassword.Text);
                    context.SaveChanges();

                    MessageBox.Show("Пароль успешно сброшен!");
                    this.Close();
                }
            }
        }
    }
}
