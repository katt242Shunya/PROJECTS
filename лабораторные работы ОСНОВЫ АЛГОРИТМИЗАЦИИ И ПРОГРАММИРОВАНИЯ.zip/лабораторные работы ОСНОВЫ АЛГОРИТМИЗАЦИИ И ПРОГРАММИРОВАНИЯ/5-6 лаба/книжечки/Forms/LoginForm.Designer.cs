﻿namespace книжечки
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxLoginOrEmail = new TextBox();
            textBoxPassword = new TextBox();
            label1 = new Label();
            label2 = new Label();
            buttonLogin = new Button();
            buttonRegister = new Button();
            buttonRecoverPassword = new Button();
            label3 = new Label();
            SuspendLayout();
            // 
            // textBoxLoginOrEmail
            // 
            textBoxLoginOrEmail.Font = new Font("Century Gothic", 9F);
            textBoxLoginOrEmail.Location = new Point(512, 128);
            textBoxLoginOrEmail.Name = "textBoxLoginOrEmail";
            textBoxLoginOrEmail.Size = new Size(381, 26);
            textBoxLoginOrEmail.TabIndex = 0;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Font = new Font("Century Gothic", 9F);
            textBoxPassword.Location = new Point(512, 185);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(381, 26);
            textBoxPassword.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F);
            label1.Location = new Point(120, 128);
            label1.Name = "label1";
            label1.Size = new Size(346, 20);
            label1.TabIndex = 2;
            label1.Text = "Введите логин или адрес электронной почты";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 9F);
            label2.Location = new Point(120, 188);
            label2.Name = "label2";
            label2.Size = new Size(127, 20);
            label2.TabIndex = 3;
            label2.Text = "Введите пароль";
            // 
            // buttonLogin
            // 
            buttonLogin.Font = new Font("Century Gothic", 9F);
            buttonLogin.Location = new Point(302, 270);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(164, 50);
            buttonLogin.TabIndex = 4;
            buttonLogin.Text = "Войти";
            buttonLogin.UseVisualStyleBackColor = true;
            buttonLogin.Click += buttonLogin_Click;
            // 
            // buttonRegister
            // 
            buttonRegister.Font = new Font("Century Gothic", 9F);
            buttonRegister.Location = new Point(512, 270);
            buttonRegister.Name = "buttonRegister";
            buttonRegister.Size = new Size(229, 50);
            buttonRegister.TabIndex = 5;
            buttonRegister.Text = "Зарегестрироваться";
            buttonRegister.UseVisualStyleBackColor = true;
            buttonRegister.Click += buttonRegister_Click;
            // 
            // buttonRecoverPassword
            // 
            buttonRecoverPassword.BackColor = Color.Snow;
            buttonRecoverPassword.Font = new Font("Century Gothic", 6F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonRecoverPassword.Location = new Point(313, 326);
            buttonRecoverPassword.Name = "buttonRecoverPassword";
            buttonRecoverPassword.Size = new Size(137, 26);
            buttonRecoverPassword.TabIndex = 6;
            buttonRecoverPassword.Text = "Забыли пароль?((";
            buttonRecoverPassword.UseVisualStyleBackColor = false;
            buttonRecoverPassword.Click += buttonRecoverPassword_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(313, 38);
            label3.Name = "label3";
            label3.Size = new Size(378, 40);
            label3.TabIndex = 7;
            label3.Text = "Книжный магазинчик";
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Thistle;
            ClientSize = new Size(1001, 583);
            Controls.Add(label3);
            Controls.Add(buttonRecoverPassword);
            Controls.Add(buttonRegister);
            Controls.Add(buttonLogin);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxPassword);
            Controls.Add(textBoxLoginOrEmail);
            Name = "LoginForm";
            Text = "Form1";
            Load += LoginForm_Load;
            Click += LoginForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxLoginOrEmail;
        private TextBox textBoxPassword;
        private Label label1;
        private Label label2;
        private Button buttonLogin;
        private Button buttonRegister;
        private Button buttonRecoverPassword;
        private Label label3;
    }
}
