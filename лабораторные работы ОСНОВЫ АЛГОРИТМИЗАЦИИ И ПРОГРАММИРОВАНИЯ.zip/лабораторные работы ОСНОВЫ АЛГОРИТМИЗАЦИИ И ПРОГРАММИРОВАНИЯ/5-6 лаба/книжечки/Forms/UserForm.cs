﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using книжечки.Data;
using книжечки.Utils;
using книжечки.Models;

namespace книжечки.Forms
{
    public partial class UserForm : Form
    {
        private readonly AppDbContext _context = new AppDbContext();
        private readonly User _user;
        private readonly List<Book> cart = new List<Book>();

        public UserForm(User user)
        {
            InitializeComponent();
            _user = user;
            LoadBooks();
        }

        private void LoadBooks()
        {
            dataGridViewBooks.DataSource = _context.Books.ToList();
        }

        private void buttonAddToCart_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.CurrentRow == null)
            {
                MessageBox.Show("Выберите книгу.");
                return;
            }

            var book = dataGridViewBooks.CurrentRow.DataBoundItem as Book;
            if (book != null)
            {
                cart.Add(book);
                MessageBox.Show($"Книга «{book.Title}» добавлена в корзину!");
            }
        }



        private void buttonOpenCart_Click(object sender, EventArgs e)
        {
            var cartForm = new CartForm(cart, _user);
            cartForm.ShowDialog();
        }

        private void buttonOrders_Click(object sender, EventArgs e)
        {
            var ordersForm = new OrderListForm(_user);
            ordersForm.ShowDialog();
        }

    }
}
