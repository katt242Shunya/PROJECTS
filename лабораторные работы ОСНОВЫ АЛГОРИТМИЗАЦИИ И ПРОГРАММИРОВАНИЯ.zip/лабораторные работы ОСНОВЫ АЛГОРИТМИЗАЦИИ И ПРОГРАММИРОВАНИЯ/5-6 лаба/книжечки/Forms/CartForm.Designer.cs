﻿namespace книжечки.Forms
{
    partial class CartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonRemove = new Button();
            dataGridViewCart = new DataGridView();
            buttonCheckout = new Button();
            labelTotal = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCart).BeginInit();
            SuspendLayout();
            // 
            // buttonRemove
            // 
            buttonRemove.Font = new Font("Century Gothic", 9F);
            buttonRemove.Location = new Point(837, 55);
            buttonRemove.Name = "buttonRemove";
            buttonRemove.Size = new Size(139, 52);
            buttonRemove.TabIndex = 3;
            buttonRemove.Text = "Удалить из корзинки";
            buttonRemove.UseVisualStyleBackColor = true;
            buttonRemove.Click += buttonRemove_Click;
            // 
            // dataGridViewCart
            // 
            dataGridViewCart.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewCart.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCart.Location = new Point(12, 12);
            dataGridViewCart.Name = "dataGridViewCart";
            dataGridViewCart.RowHeadersWidth = 51;
            dataGridViewCart.Size = new Size(804, 460);
            dataGridViewCart.TabIndex = 2;
            // 
            // buttonCheckout
            // 
            buttonCheckout.Font = new Font("Century Gothic", 9F);
            buttonCheckout.Location = new Point(519, 527);
            buttonCheckout.Name = "buttonCheckout";
            buttonCheckout.Size = new Size(228, 29);
            buttonCheckout.TabIndex = 4;
            buttonCheckout.Text = "Оформить заказ!";
            buttonCheckout.UseVisualStyleBackColor = true;
            buttonCheckout.Click += buttonCheckout_Click;
            // 
            // labelTotal
            // 
            labelTotal.AutoSize = true;
            labelTotal.Location = new Point(519, 492);
            labelTotal.Name = "labelTotal";
            labelTotal.Size = new Size(13, 20);
            labelTotal.TabIndex = 5;
            labelTotal.Text = " ";
            // 
            // CartForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkViolet;
            ClientSize = new Size(1001, 583);
            Controls.Add(labelTotal);
            Controls.Add(buttonCheckout);
            Controls.Add(buttonRemove);
            Controls.Add(dataGridViewCart);
            Name = "CartForm";
            Text = "CartForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewCart).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonRemove;
        private DataGridView dataGridViewCart;
        private Button buttonCheckout;
        private Label labelTotal;
    }
}