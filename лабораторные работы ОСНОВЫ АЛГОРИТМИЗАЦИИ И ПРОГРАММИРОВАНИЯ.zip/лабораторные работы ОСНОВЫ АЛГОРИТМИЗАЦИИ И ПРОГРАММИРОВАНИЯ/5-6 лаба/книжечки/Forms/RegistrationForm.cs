﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using книжечки.Data;
using книжечки.Utils;
using книжечки.Models;

namespace книжечки.Forms
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text.Trim();
            string email = textBoxEmail.Text.Trim();
            string password = textBoxPassword.Text;

            if (string.IsNullOrWhiteSpace(login) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(login, @"^[a-zA-Z][a-zA-Z0-9]*$"))
            {
                MessageBox.Show("Логин должен начинаться с буквы и содержать только буквы и цифры.");
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Введите корректный адрес электронной почты.");
                return;
            }

            if (password.Length < 8)
            {
                MessageBox.Show("Пароль должен содержать не менее 8 символов.");
                return;
            }

            using (var context = new AppDbContext())
            {
                if (context.Users.Any(u => u.Email == email))
                {
                    MessageBox.Show("Пользователь с такой почтой уже существует!");
                    return;
                }

                if (context.Users.Any(u => u.Login == login))
                {
                    MessageBox.Show("Пользователь с таким логином уже существует!");
                    return;
                }

                var user = new User
                {
                    Login = login,
                    Email = email,
                    PasswordHash = PasswordHelper.GetHashString(password),
                    Role = "User"
                };

                context.Users.Add(user);
                context.SaveChanges();
            }

            MessageBox.Show("Вы успешно зарегистрировались!", "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

    }
}
