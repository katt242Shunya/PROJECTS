﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using книжечки.Data;
using книжечки.Models;

namespace книжечки.Forms
{
    public partial class CartForm : Form
    {
        private readonly List<Book> _cart;
        private readonly User _user;

        public CartForm(List<Book> cart, User user)
        {
            InitializeComponent();
            _cart = cart;
            _user = user;
            LoadCart();
        }

        private void LoadCart()
        {
            dataGridViewCart.DataSource = null;
            dataGridViewCart.DataSource = _cart.ToList();

            labelTotal.Text = $"Итого: {_cart.Sum(b => b.Price):C}";
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (dataGridViewCart.CurrentRow == null) return;

            var book = dataGridViewCart.CurrentRow.DataBoundItem as Book;
            if (book != null)
            {
                _cart.Remove(book);
                LoadCart();
            }
        }

        private void buttonCheckout_Click(object sender, EventArgs e)
        {
            if (_cart.Count == 0)
            {
                MessageBox.Show("Ваша корзина пуста!");
                return;
            }

            using (var context = new AppDbContext())
            {
                var order = new Order
                {
                    UserId = _user.Id,
                    OrderDate = DateTime.Now,
                    Items = _cart.Select(book => new OrderItem
                    {
                        BookId = book.Id,
                        Quantity = 1
                    }).ToList()
                };

                context.Orders.Add(order);
                context.SaveChanges();
            }

            MessageBox.Show($"Заказ на сумму {_cart.Sum(b => b.Price):C} успешно оформлен!", "Заказ оформлен", MessageBoxButtons.OK, MessageBoxIcon.Information);

            _cart.Clear();
            LoadCart();
            this.Close();
        }


    }

}
