﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using книжечки.Data;
using книжечки.Models;

namespace книжечки.Forms
{
    public partial class AdminForm : Form
    {
        private readonly AppDbContext _context = new AppDbContext();

        public AdminForm(User admin)
        {
            InitializeComponent();
            LoadBooks();
        }

        private void LoadBooks()
        {
            dataGridViewBooks.DataSource = _context.Books.ToList();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            var bookForm = new BookForm(); 
            if (bookForm.ShowDialog() == DialogResult.OK)
            {
                _context.Books.Add(bookForm.Book);
                _context.SaveChanges();
                LoadBooks();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            var selectedBook = dataGridViewBooks.CurrentRow.DataBoundItem as Book;
            var bookForm = new BookForm(selectedBook);

            if (bookForm.ShowDialog() == DialogResult.OK)
            {
                selectedBook.Title = bookForm.Book.Title;
                selectedBook.Author = bookForm.Book.Author;
                selectedBook.Year = bookForm.Book.Year;
                selectedBook.Price = bookForm.Book.Price;

                _context.SaveChanges();
                LoadBooks();
            }

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.CurrentRow == null) return;

            var book = dataGridViewBooks.CurrentRow.DataBoundItem as Book;

            var result = MessageBox.Show($"Удалить книгу '{book.Title}'?", "Подтверждение", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                _context.Books.Remove(book);
                _context.SaveChanges();
                LoadBooks();
            }
        }
    }
}