﻿namespace книжечки.Forms
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewBooks = new DataGridView();
            buttonAdd = new Button();
            buttonEdit = new Button();
            buttonDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBooks).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewBooks
            // 
            dataGridViewBooks.AllowUserToAddRows = false;
            dataGridViewBooks.AllowUserToDeleteRows = false;
            dataGridViewBooks.AllowUserToResizeColumns = false;
            dataGridViewBooks.AllowUserToResizeRows = false;
            dataGridViewBooks.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBooks.GridColor = Color.Beige;
            dataGridViewBooks.Location = new Point(84, 35);
            dataGridViewBooks.Name = "dataGridViewBooks";
            dataGridViewBooks.ReadOnly = true;
            dataGridViewBooks.RowHeadersWidth = 51;
            dataGridViewBooks.Size = new Size(810, 314);
            dataGridViewBooks.TabIndex = 0;
            // 
            // buttonAdd
            // 
            buttonAdd.Font = new Font("Century Gothic", 9F);
            buttonAdd.Location = new Point(97, 497);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(238, 29);
            buttonAdd.TabIndex = 1;
            buttonAdd.Text = "Добавить книжку";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonEdit
            // 
            buttonEdit.Font = new Font("Century Gothic", 9F);
            buttonEdit.Location = new Point(410, 497);
            buttonEdit.Name = "buttonEdit";
            buttonEdit.Size = new Size(239, 29);
            buttonEdit.TabIndex = 2;
            buttonEdit.Text = "Редактировать книгу";
            buttonEdit.UseVisualStyleBackColor = true;
            buttonEdit.Click += buttonEdit_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.Font = new Font("Century Gothic", 9F);
            buttonDelete.Location = new Point(718, 497);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(159, 29);
            buttonDelete.TabIndex = 3;
            buttonDelete.Text = "Удалить книжку";
            buttonDelete.UseVisualStyleBackColor = true;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(1001, 583);
            Controls.Add(buttonDelete);
            Controls.Add(buttonEdit);
            Controls.Add(buttonAdd);
            Controls.Add(dataGridViewBooks);
            Name = "AdminForm";
            Text = "AdminForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewBooks).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewBooks;
        private Button buttonAdd;
        private Button buttonEdit;
        private Button buttonDelete;
    }
}