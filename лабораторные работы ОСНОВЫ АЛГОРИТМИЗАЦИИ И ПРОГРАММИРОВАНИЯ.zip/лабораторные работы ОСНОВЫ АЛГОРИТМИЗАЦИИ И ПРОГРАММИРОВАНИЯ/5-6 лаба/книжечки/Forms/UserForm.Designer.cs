﻿namespace книжечки.Forms
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewBooks = new DataGridView();
            buttonAddToCart = new Button();
            buttonOpenCart = new Button();
            buttonOrders = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBooks).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewBooks
            // 
            dataGridViewBooks.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBooks.Location = new Point(12, 68);
            dataGridViewBooks.Name = "dataGridViewBooks";
            dataGridViewBooks.ReadOnly = true;
            dataGridViewBooks.RowHeadersWidth = 51;
            dataGridViewBooks.Size = new Size(977, 427);
            dataGridViewBooks.TabIndex = 0;
            // 
            // buttonAddToCart
            // 
            buttonAddToCart.Font = new Font("Century Gothic", 9F);
            buttonAddToCart.Location = new Point(746, 531);
            buttonAddToCart.Name = "buttonAddToCart";
            buttonAddToCart.Size = new Size(228, 29);
            buttonAddToCart.TabIndex = 1;
            buttonAddToCart.Text = "Добавить в корзину";
            buttonAddToCart.UseVisualStyleBackColor = true;
            buttonAddToCart.Click += buttonAddToCart_Click;
            // 
            // buttonOpenCart
            // 
            buttonOpenCart.Font = new Font("Century Gothic", 9F);
            buttonOpenCart.Location = new Point(21, 22);
            buttonOpenCart.Name = "buttonOpenCart";
            buttonOpenCart.Size = new Size(228, 29);
            buttonOpenCart.TabIndex = 2;
            buttonOpenCart.Text = "Перейти в корзину";
            buttonOpenCart.UseVisualStyleBackColor = true;
            buttonOpenCart.Click += buttonOpenCart_Click;
            // 
            // buttonOrders
            // 
            buttonOrders.Font = new Font("Century Gothic", 9F);
            buttonOrders.Location = new Point(746, 22);
            buttonOrders.Name = "buttonOrders";
            buttonOrders.Size = new Size(228, 29);
            buttonOrders.TabIndex = 3;
            buttonOrders.Text = "Мои заказы";
            buttonOrders.UseVisualStyleBackColor = true;
            buttonOrders.Click += buttonOrders_Click;
            // 
            // UserForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkViolet;
            ClientSize = new Size(1001, 583);
            Controls.Add(buttonOrders);
            Controls.Add(buttonOpenCart);
            Controls.Add(buttonAddToCart);
            Controls.Add(dataGridViewBooks);
            Name = "UserForm";
            Text = "UserForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewBooks).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewBooks;
        private Button buttonAddToCart;
        private Button buttonOpenCart;
        private Button buttonOrders;
    }
}