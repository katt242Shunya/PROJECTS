﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using книжечки.Data;
using книжечки.Models;

namespace книжечки.Forms
{
    public partial class BookForm : Form
    {
        public Book Book { get; private set; }

        public BookForm()
        {
            InitializeComponent();
            SetupControls();
            Book = new Book();
        }

        public BookForm(Book bookToEdit)
        {
            InitializeComponent();
            SetupControls();
            Book = new Book
            {
                Id = bookToEdit.Id,
                Title = bookToEdit.Title,
                Author = bookToEdit.Author,
                Year = bookToEdit.Year,
                Price = bookToEdit.Price
            };

            textBoxTitle.Text = Book.Title;
            textBoxAuthor.Text = Book.Author;
            numericUpDownYear.Value = Book.Year;
            numericUpDownPrice.Value = Book.Price;
        }

        private void SetupControls()
        {
            numericUpDownYear.Minimum = 1800;
            numericUpDownYear.Maximum = 2025;
            numericUpDownYear.Value = 2024;

            numericUpDownPrice.Minimum = 0;
            numericUpDownPrice.Maximum = 100000;
            numericUpDownPrice.DecimalPlaces = 2;
            numericUpDownPrice.Increment = 0.01M;
            numericUpDownPrice.Value = 500;
        }


        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxTitle.Text))
            {
                MessageBox.Show("Название книги не может быть пустым.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxAuthor.Text))
            {
                MessageBox.Show("Автор книги не может быть пустым.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var context = new AppDbContext())
            {
                bool isTitleTaken = context.Books
                    .Any(b => b.Title == textBoxTitle.Text && b.Id != Book.Id); 

                if (isTitleTaken)
                {
                    MessageBox.Show("Книга с таким названием уже существует.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            Book.Title = textBoxTitle.Text;
            Book.Author = textBoxAuthor.Text;
            Book.Year = (int)numericUpDownYear.Value;
            Book.Price = numericUpDownPrice.Value;

            DialogResult = DialogResult.OK;
            Close();
        }


    }
}