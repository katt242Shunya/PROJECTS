﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using книжечки.Models;
using книжечки.Utils;

namespace книжечки.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\mssqllocaldb;Initial Catalog=BookStoreDb;Integrated Security=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();
            modelBuilder.Entity<User>().HasIndex(u => u.Login).IsUnique();

            modelBuilder.Entity<Book>(entity =>
            {
                entity.HasIndex(b => b.Title).IsUnique(); 

                entity.Property(b => b.Title)
                    .IsRequired(); 

                entity.Property(b => b.Author)
                    .IsRequired(); 
            });

            base.OnModelCreating(modelBuilder);

            var admin = new User
            {
                Id = 1000,
                Login = "admin",
                Email = "admin@bookstore.com",
                PasswordHash = PasswordHelper.GetHashString("YaTutGlavnaya"),
                Role = "Admin"
            };

            modelBuilder.Entity<User>().HasData(admin);
        }


    }

}
