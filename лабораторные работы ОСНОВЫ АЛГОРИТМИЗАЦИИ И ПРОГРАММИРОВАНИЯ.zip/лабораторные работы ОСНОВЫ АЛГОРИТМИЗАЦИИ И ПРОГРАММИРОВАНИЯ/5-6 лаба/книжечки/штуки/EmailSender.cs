﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace книжечки.Utils
{
    public static class EmailSender
    {
        public static void SendCode(string toEmail, string code)
        {
            var from = new MailAddress("nikulinak16@mail.ru", "BookStoreApp");
            var to = new MailAddress(toEmail);

            var message = new MailMessage(from, to);
            message.Subject = "Восстановление пароля";
            message.Body = $"Ваш код восстановления: {code}";
            message.IsBodyHtml = false;

            var smtp = new SmtpClient("smtp.mail.ru", 587);
            smtp.Credentials = new NetworkCredential("nikulinak16@mail.ru", "sGHvXB1bHgA7z1vVeQtJ");
            smtp.EnableSsl = true;

            smtp.Send(message);
        }
    }
}
