﻿namespace лаба10
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            buttonSort = new Button();
            radioButtonShell = new RadioButton();
            radioButtonInsertion = new RadioButton();
            groupBox2 = new GroupBox();
            buttonSave = new Button();
            buttonLoad = new Button();
            labelTime = new Label();
            labelSwaps = new Label();
            labelComparisons = new Label();
            clean = new Button();
            saveFileDialog = new SaveFileDialog();
            openFileDialog = new OpenFileDialog();
            numericUpDownArraySize = new NumericUpDown();
            buttonGenerateArray = new Button();
            groupBox3 = new GroupBox();
            label4 = new Label();
            TextBoxArray = new RichTextBox();
            buttonAnaliz = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownArraySize).BeginInit();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonFace;
            groupBox1.Controls.Add(buttonSort);
            groupBox1.Controls.Add(radioButtonShell);
            groupBox1.Controls.Add(radioButtonInsertion);
            groupBox1.Location = new Point(12, 132);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(327, 177);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Выбор метода сортировки";
            // 
            // buttonSort
            // 
            buttonSort.BackColor = SystemColors.InactiveCaption;
            buttonSort.Location = new Point(30, 114);
            buttonSort.Name = "buttonSort";
            buttonSort.Size = new Size(256, 43);
            buttonSort.TabIndex = 2;
            buttonSort.Text = "Начать сортировку";
            buttonSort.UseVisualStyleBackColor = false;
            buttonSort.Click += buttonSort_Click;
            // 
            // radioButtonShell
            // 
            radioButtonShell.AutoSize = true;
            radioButtonShell.Location = new Point(30, 65);
            radioButtonShell.Name = "radioButtonShell";
            radioButtonShell.Size = new Size(124, 24);
            radioButtonShell.TabIndex = 1;
            radioButtonShell.TabStop = true;
            radioButtonShell.Text = "Метод Шелла";
            radioButtonShell.UseVisualStyleBackColor = true;
            // 
            // radioButtonInsertion
            // 
            radioButtonInsertion.AutoSize = true;
            radioButtonInsertion.Location = new Point(30, 35);
            radioButtonInsertion.Name = "radioButtonInsertion";
            radioButtonInsertion.Size = new Size(131, 24);
            radioButtonInsertion.TabIndex = 0;
            radioButtonInsertion.TabStop = true;
            radioButtonInsertion.Text = "Метод вставок";
            radioButtonInsertion.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.ButtonFace;
            groupBox2.Controls.Add(buttonSave);
            groupBox2.Controls.Add(buttonLoad);
            groupBox2.Controls.Add(labelTime);
            groupBox2.Controls.Add(labelSwaps);
            groupBox2.Controls.Add(labelComparisons);
            groupBox2.Location = new Point(12, 315);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(529, 218);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Данные о сортировке";
            // 
            // buttonSave
            // 
            buttonSave.BackColor = Color.DarkSeaGreen;
            buttonSave.Location = new Point(6, 150);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(228, 51);
            buttonSave.TabIndex = 6;
            buttonSave.Text = "Сохранить файл";
            buttonSave.UseVisualStyleBackColor = false;
            buttonSave.Click += buttonSave_Click;
            // 
            // buttonLoad
            // 
            buttonLoad.Location = new Point(367, 157);
            buttonLoad.Name = "buttonLoad";
            buttonLoad.Size = new Size(135, 36);
            buttonLoad.TabIndex = 4;
            buttonLoad.Text = "Открыть файл";
            buttonLoad.UseVisualStyleBackColor = true;
            buttonLoad.Click += buttonLoad_Click;
            // 
            // labelTime
            // 
            labelTime.AutoSize = true;
            labelTime.Location = new Point(21, 113);
            labelTime.Name = "labelTime";
            labelTime.Size = new Size(140, 20);
            labelTime.TabIndex = 5;
            labelTime.Text = "Время сортировки";
            // 
            // labelSwaps
            // 
            labelSwaps.AutoSize = true;
            labelSwaps.Location = new Point(21, 78);
            labelSwaps.Name = "labelSwaps";
            labelSwaps.Size = new Size(191, 20);
            labelSwaps.TabIndex = 4;
            labelSwaps.Text = "Количество перестановок";
            // 
            // labelComparisons
            // 
            labelComparisons.AutoSize = true;
            labelComparisons.Location = new Point(21, 42);
            labelComparisons.Name = "labelComparisons";
            labelComparisons.Size = new Size(170, 20);
            labelComparisons.TabIndex = 3;
            labelComparisons.Text = "Количество сравнений";
            // 
            // clean
            // 
            clean.BackColor = SystemColors.InactiveCaption;
            clean.Location = new Point(137, 553);
            clean.Name = "clean";
            clean.Size = new Size(256, 43);
            clean.TabIndex = 2;
            clean.Text = "Очистить ";
            clean.UseVisualStyleBackColor = false;
            // 
            // openFileDialog
            // 
            openFileDialog.FileName = "openFileDialog1";
            // 
            // numericUpDownArraySize
            // 
            numericUpDownArraySize.Location = new Point(333, 21);
            numericUpDownArraySize.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            numericUpDownArraySize.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownArraySize.Name = "numericUpDownArraySize";
            numericUpDownArraySize.Size = new Size(223, 27);
            numericUpDownArraySize.TabIndex = 4;
            numericUpDownArraySize.Value = new decimal(new int[] { 40, 0, 0, 0 });
            // 
            // buttonGenerateArray
            // 
            buttonGenerateArray.BackColor = SystemColors.InactiveCaption;
            buttonGenerateArray.Location = new Point(55, 59);
            buttonGenerateArray.Name = "buttonGenerateArray";
            buttonGenerateArray.Size = new Size(256, 43);
            buttonGenerateArray.TabIndex = 3;
            buttonGenerateArray.Text = "Создать";
            buttonGenerateArray.UseVisualStyleBackColor = false;
            buttonGenerateArray.Click += buttonGenerateArray_Click;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = SystemColors.ButtonFace;
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(numericUpDownArraySize);
            groupBox3.Controls.Add(buttonGenerateArray);
            groupBox3.Location = new Point(12, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(550, 114);
            groupBox3.TabIndex = 3;
            groupBox3.TabStop = false;
            groupBox3.Text = "Генератор массива";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 23);
            label4.Name = "label4";
            label4.Size = new Size(321, 20);
            label4.TabIndex = 5;
            label4.Text = "Выбрите количество элементов для массива";
            // 
            // TextBoxArray
            // 
            TextBoxArray.Location = new Point(574, 12);
            TextBoxArray.Name = "TextBoxArray";
            TextBoxArray.Size = new Size(823, 628);
            TextBoxArray.TabIndex = 4;
            TextBoxArray.Text = "";
            // 
            // buttonAnaliz
            // 
            buttonAnaliz.Location = new Point(12, 611);
            buttonAnaliz.Name = "buttonAnaliz";
            buttonAnaliz.Size = new Size(446, 29);
            buttonAnaliz.TabIndex = 5;
            buttonAnaliz.Text = "Посмотреть сравнительный анализ";
            buttonAnaliz.UseVisualStyleBackColor = true;
            buttonAnaliz.Click += buttonAnaliz_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            ClientSize = new Size(1409, 652);
            Controls.Add(buttonAnaliz);
            Controls.Add(TextBoxArray);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Controls.Add(clean);
            Name = "Form1";
            Text = "laba4";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownArraySize).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox groupBox1;
        private Button buttonSort;
        private RadioButton radioButtonShell;
        private RadioButton radioButtonInsertion;
        private GroupBox groupBox2;
        private Label labelTime;
        private Label labelSwaps;
        private Label labelComparisons;
        private Button clean;
        private SaveFileDialog saveFileDialog;
        private OpenFileDialog openFileDialog;
        private NumericUpDown numericUpDownArraySize;
        private Button buttonGenerateArray;
        private GroupBox groupBox3;
        private Label label4;
        private Button buttonLoad;
        private Button buttonSave;
        private RichTextBox TextBoxArray;
        private Button buttonAnaliz;
    }
}
