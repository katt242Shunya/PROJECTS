﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace лаба10
{
    public partial class SravnitelniyAnaliz : Form
    {
        public SravnitelniyAnaliz()
        {
            InitializeComponent();
            LoadAnalysisData();
        }

        private void LoadAnalysisData()
        {
            try
            {
                if (ComparativeAnalysis.InsertionSortStats.Count == 0)
                {
                    ComparativeAnalysis.PerformComparativeAnalysis();
                }

                listViewResults.Items.Clear();

                foreach (var size in new[] { 10, 100, 1000 })
                {
                    var insertionData = ComparativeAnalysis.InsertionSortStats[size];
                    var shellData = ComparativeAnalysis.ShellSortStats[size];

                    var item = new ListViewItem(size.ToString());
                    item.SubItems.Add($"C: {insertionData.comparisons} П: {insertionData.swaps} t: {FormatTime(insertionData.time)}");
                    item.SubItems.Add($"C: {shellData.comparisons} П: {shellData.swaps} t: {FormatTime(shellData.time)}");

                    listViewResults.Items.Add(item);
                }

                UpdateInfoLabel();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string FormatTime(TimeSpan time)
        {
            return time.TotalMilliseconds < 1 ?
                "00:00:00.000" :
                $"{(int)time.TotalHours:00}:{time.Minutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
        }

        private void UpdateInfoLabel()
        {
            if (ComparativeAnalysis.InsertionSortStats.Count == 0 ||
                ComparativeAnalysis.ShellSortStats.Count == 0)
            {
                labelInfo.Text = "Данные для анализа отсутствуют.";
                return;
            }

            var worstInsertion = ComparativeAnalysis.InsertionSortStats
                .OrderByDescending(x => x.Value.comparisons)
                .First();

            var bestShell = ComparativeAnalysis.ShellSortStats
                .OrderBy(x => x.Value.comparisons)
                .First();

            labelInfo.Text = $"Метод обмена с количеством сравнений равным {worstInsertion.Value.comparisons} " +
                           $"дает худшие показатели трудоемкости сортировки для массива с количеством " +
                           $"элементов равным {worstInsertion.Key}.\n\n" +
                           $"Метод Шелла с количеством сравнений равным {bestShell.Value.comparisons} " +
                           $"дает лучшие показатели трудоемкости сортировки для массива с количеством " +
                           $"элементов равным {bestShell.Key}.";
        }

        private void buttonAnaliz_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            Hide();
        }
    }
}