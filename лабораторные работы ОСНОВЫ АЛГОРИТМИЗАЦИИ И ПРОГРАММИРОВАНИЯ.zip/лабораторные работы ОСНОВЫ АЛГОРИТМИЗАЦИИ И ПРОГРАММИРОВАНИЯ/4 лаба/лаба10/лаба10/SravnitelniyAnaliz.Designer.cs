﻿namespace лаба10
{
    partial class SravnitelniyAnaliz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAnaliz = new Button();
            listViewResults = new ListView();
            объем = new ColumnHeader();
            сортировка_вставками = new ColumnHeader();
            метод_шелла = new ColumnHeader();
            labelInfo = new Label();
            SuspendLayout();
            // 
            // buttonAnaliz
            // 
            buttonAnaliz.Location = new Point(30, 401);
            buttonAnaliz.Name = "buttonAnaliz";
            buttonAnaliz.Size = new Size(276, 29);
            buttonAnaliz.TabIndex = 6;
            buttonAnaliz.Text = "Вернуться на форму генерации";
            buttonAnaliz.UseVisualStyleBackColor = true;
            buttonAnaliz.Click += buttonAnaliz_Click;
            // 
            // listViewResults
            // 
            listViewResults.Columns.AddRange(new ColumnHeader[] { объем, сортировка_вставками, метод_шелла });
            listViewResults.FullRowSelect = true;
            listViewResults.GridLines = true;
            listViewResults.Location = new Point(30, 12);
            listViewResults.Name = "listViewResults";
            listViewResults.Size = new Size(606, 130);
            listViewResults.TabIndex = 7;
            listViewResults.UseCompatibleStateImageBehavior = false;
            listViewResults.View = View.Details;
            // 
            // объем
            // 
            объем.Text = "объем";
            объем.Width = 100;
            // 
            // сортировка_вставками
            // 
            сортировка_вставками.Text = "сортировка_вставками";
            сортировка_вставками.Width = 250;
            // 
            // метод_шелла
            // 
            метод_шелла.Text = "метод_шелла";
            метод_шелла.Width = 250;
            // 
            // labelInfo
            // 
            labelInfo.AutoSize = true;
            labelInfo.Location = new Point(30, 231);
            labelInfo.Name = "labelInfo";
            labelInfo.Size = new Size(13, 20);
            labelInfo.TabIndex = 8;
            labelInfo.Text = " ";
            // 
            // SravnitelniyAnaliz
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1189, 456);
            Controls.Add(labelInfo);
            Controls.Add(listViewResults);
            Controls.Add(buttonAnaliz);
            Name = "SravnitelniyAnaliz";
            Text = "SravnitelniyAnaliz";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonAnaliz;
        private ListView listViewResults;
        private ColumnHeader объем;
        private ColumnHeader сортировка_вставками;
        private ColumnHeader метод_шелла;
        private Label labelInfo;
    }
}