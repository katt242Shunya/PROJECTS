﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace лаба10
{
    public interface IStrategy
    {
        int[] Algorithm(int[] mas, bool flag = true);
    }

    public static class ComparativeAnalysis
    {
        public static int Comparison { get; set; }
        public static int NumberOfPermutations { get; set; }
        public static ObservableCollection<string> SortSteps { get; set; } = [];

        public static Dictionary<int, (int comparisons, int swaps, TimeSpan time)> InsertionSortStats { get; }
            = [];
        public static Dictionary<int, (int comparisons, int swaps, TimeSpan time)> ShellSortStats { get; }
            = [];

        public static void Reset()
        {
            Comparison = 0;
            NumberOfPermutations = 0;
            SortSteps.Clear();
        }

        public static void PerformComparativeAnalysis()
        {
            int[] testSizes = { 10, 100, 1000 }; 
            Random rand = new Random();

            foreach (int size in testSizes)
            {
                
                int[] array = new int[size];
                for (int i = 0; i < size; i++)
                {
                    array[i] = rand.Next(1, 1000);
                }

                var insertionSort = new InsertionSort();
                int[] insertionArray = (int[])array.Clone();
                Stopwatch sw = Stopwatch.StartNew();
                insertionSort.Algorithm(insertionArray);
                sw.Stop();
                InsertionSortStats[size] = (Comparison, NumberOfPermutations, sw.Elapsed);
                Reset();

                var shellSort = new ShellSort();
                int[] shellArray = (int[])array.Clone();
                sw.Restart();
                shellSort.Algorithm(shellArray);
                sw.Stop();
                ShellSortStats[size] = (Comparison, NumberOfPermutations, sw.Elapsed);
                Reset();
            }
        }
    }

    public class InsertionSort : IStrategy
    {
        public int[] Algorithm(int[] mas, bool flag = true)
        {
            ComparativeAnalysis.Comparison = 0;
            ComparativeAnalysis.NumberOfPermutations = 0;
            ComparativeAnalysis.Reset();

            for (int i = 1; i < mas.Length; i++)
            {
                int key = mas[i];
                int j = i - 1;
                while (j >= 0 && mas[j] > key)
                {
                    ComparativeAnalysis.Comparison++;
                    ComparativeAnalysis.SortSteps.Add($"Сравнение: {mas[j]} > {key}");
                    mas[j + 1] = mas[j];
                    ComparativeAnalysis.NumberOfPermutations++;
                    ComparativeAnalysis.SortSteps.Add($"Состояние: {string.Join(" ", mas)}");
                    j--;
                }
                mas[j + 1] = key;
            }
            return mas;
        }
    }

    public class ShellSort : IStrategy
    {
        public int[] Algorithm(int[] mas, bool flag = true)
        {
            ComparativeAnalysis.Comparison = 0;
            ComparativeAnalysis.NumberOfPermutations = 0;
            ComparativeAnalysis.Reset();

            int gap = mas.Length / 2;
            while (gap > 0)
            {
                for (int i = gap; i < mas.Length; i++)
                {
                    int temp = mas[i];
                    int j = i;
                    while (j >= gap && mas[j - gap] > temp)
                    {
                        ComparativeAnalysis.Comparison++;
                        ComparativeAnalysis.SortSteps.Add($"Сравнение: {mas[j - gap]} > {temp}");
                        mas[j] = mas[j - gap];
                        ComparativeAnalysis.NumberOfPermutations++;
                        ComparativeAnalysis.SortSteps.Add($"Состояние: {string.Join(" ", mas)}");
                        j -= gap;
                    }
                    mas[j] = temp;
                }
                gap /= 2;
            }
            return mas;
        }
    }

    public class Context
    {
        public IStrategy ContextStrategy { get; set; }
        public static int[] array;
        public static int[] originalArray;

        public Context(IStrategy strategy)
        {
            ContextStrategy = strategy;
        }

        public void ExecuteAlgorithm(bool flag = true)
        {
            originalArray = (int[])array.Clone();
            ContextStrategy.Algorithm(array, flag);
        }
    }
}