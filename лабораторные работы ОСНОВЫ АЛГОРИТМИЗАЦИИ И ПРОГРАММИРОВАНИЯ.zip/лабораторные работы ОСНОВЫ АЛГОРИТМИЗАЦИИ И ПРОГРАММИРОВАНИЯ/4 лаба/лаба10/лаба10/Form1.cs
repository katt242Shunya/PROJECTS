using System;
using System.Diagnostics;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace лаба10
{
    public partial class Form1 : Form
    {
        private Context context;
        private bool isArrayGenerated = false;

        public Form1()
        {
            InitializeComponent();
            context = new Context(new InsertionSort());
            buttonSort.Enabled = false;
            buttonSave.Enabled = false;

            saveFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            saveFileDialog.DefaultExt = "txt";
            saveFileDialog.AddExtension = true;

            ComparativeAnalysis.Reset();
            ComparativeAnalysis.SortSteps.CollectionChanged += SortSteps_CollectionChanged;
        }

        private void buttonGenerateArray_Click(object sender, EventArgs e)
        {
            try
            {
                int size = (int)numericUpDownArraySize.Value;
                if (size <= 0)
                {
                    MessageBox.Show("Размер массива должен быть больше 0!");
                    return;
                }

                Random rand = new Random();
                Context.array = new int[size];
                for (int i = 0; i < size; i++)
                {
                    Context.array[i] = rand.Next(1, 1000);
                }

                Context.originalArray = (int[])Context.array.Clone();

                ComparativeAnalysis.Reset();
                UpdateUI("Сгенерированный массив:");
                isArrayGenerated = true;
                buttonSort.Enabled = true;
                buttonSave.Enabled = true;
                labelComparisons.Text = "Сравнений:";
                labelSwaps.Text = "Перестановок:";
                labelTime.Text = "Время:";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при генерации массива: {ex.Message}");
            }
        }

        private void buttonSort_Click(object sender, EventArgs e)
        {
            try
            {
                if (!isArrayGenerated || Context.array == null || Context.array.Length == 0)
                {
                    MessageBox.Show("Сначала создайте массив!");
                    return;
                }
                if (Context.originalArray == null)
                {
                    Context.originalArray = (int[])Context.array.Clone();
                }
                else
                {
                    Context.array = (int[])Context.originalArray.Clone();
                }

                TextBoxArray.Clear();
                TextBoxArray.AppendText("Начало сортировки:\n");
                TextBoxArray.AppendText(string.Join(" ", Context.array) + "\n\n");

                Stopwatch stopwatch = Stopwatch.StartNew();
                ComparativeAnalysis.Reset();

                if (radioButtonInsertion.Checked)
                    context = new Context(new InsertionSort());
                else if (radioButtonShell.Checked)
                    context = new Context(new ShellSort());

                context.ExecuteAlgorithm();
                stopwatch.Stop();

                labelComparisons.Text = $"Сравнений: {ComparativeAnalysis.Comparison}";
                labelSwaps.Text = $"Перестановок: {ComparativeAnalysis.NumberOfPermutations}";

                if (stopwatch.ElapsedMilliseconds == 0)
                {
                    long microseconds = stopwatch.ElapsedTicks / (Stopwatch.Frequency / 1_000_000);
                    labelTime.Text = $"Время: <1 мс ({microseconds} мкс)";
                }
                else
                {
                    var time = stopwatch.Elapsed;
                    string formattedTime = $"{(int)time.TotalHours:00}:{time.Minutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
                    labelTime.Text = $"Время: {formattedTime}";
                }

                TextBoxArray.AppendText("\nРезультат сортировки:\n");
                TextBoxArray.AppendText(string.Join(" ", Context.array) + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сортировке: {ex.Message}");
            }
        }

        private void SortSteps_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add && Context.array != null)
            {
                foreach (string newItem in e.NewItems)
                {
                    string[] parts = newItem.Split(["Сравнение: ", " > "], StringSplitOptions.RemoveEmptyEntries);

                    if (parts.Length >= 2)
                    {
                        string firstElement = parts[0];
                        string secondElement = parts[1];

                        this.Invoke((MethodInvoker)delegate
                        {
                            string arrayState = "Сравнение: ";
                            foreach (var item in Context.array)
                            {
                                string itemStr = item.ToString();
                                if (itemStr == firstElement || itemStr == secondElement)
                                {
                                    arrayState += $"[{item}] ";
                                }
                                else
                                {
                                    arrayState += $"{item} ";
                                }
                            }
                            TextBoxArray.AppendText(arrayState + "\n");
                        });
                    }
                }
            }
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt";
                openFileDialog.DefaultExt = "txt";
                openFileDialog.Title = "Выберите файл с результатами сортировки";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] allLines = File.ReadAllLines(openFileDialog.FileName, System.Text.Encoding.UTF8);

                    string arrayLine = null;
                    foreach (string line in allLines)
                    {
                        string trimmedLine = line.Trim();
                        if (string.IsNullOrEmpty(trimmedLine)) continue;

                        string[] parts = trimmedLine.Split(new[] { ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Any(part => int.TryParse(part, out _)))
                        {
                            arrayLine = trimmedLine.Replace("\r", "").Replace("\n", "");
                            break;
                        }
                    }

                    if (arrayLine == null)
                    {
                        MessageBox.Show("Файл не содержит распознаваемых числовых данных.\n" +
                                      "Пожалуйста, выберите файл, созданный этой программой, или файл с корректным форматом.",
                                      "Ошибка загрузки",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                        return;
                    }

                    string[] numberStrings = arrayLine.Split(
                        new[] { ' ', '\t', ',', ';' },
                        StringSplitOptions.RemoveEmptyEntries);

                    List<int> numbers = new List<int>();
                    foreach (string numStr in numberStrings)
                    {
                        if (int.TryParse(numStr, out int number))
                        {
                            numbers.Add(number);
                        }
                        else
                        {
                            Console.WriteLine($"Не удалось преобразовать '{numStr}' в число.");
                            MessageBox.Show($"Не удалось преобразовать '{numStr}' в число.  Возможно, в файле есть некорректные данные.",
                                          "Предупреждение",
                                          MessageBoxButtons.OK,
                                          MessageBoxIcon.Warning);
                        }
                    }

                    if (numbers.Count == 0)
                    {
                        MessageBox.Show("Не удалось извлечь числа из файла",
                                      "Ошибка",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                        return;
                    }

                    Context.array = numbers.ToArray();
                    Context.originalArray = (int[])Context.array.Clone();

                    UpdateUI($"Массив из файла ({numbers.Count} элементов):");
                    isArrayGenerated = true;
                    buttonSort.Enabled = true;
                    buttonSave.Enabled = true;
                    ResetStats();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке файла:\n{ex.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void ResetStats()
        {
            labelComparisons.Text = "Сравнений:";
            labelSwaps.Text = "Перестановок:";
            labelTime.Text = "Время:";
            ComparativeAnalysis.Reset();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!isArrayGenerated || Context.array == null)
                {
                    MessageBox.Show("Нет данных для сохранения!");
                    return;
                }

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string content = "Исходный массив:\n";
                    content += string.Join(" ", Context.originalArray) + "\n\n";

                    content += $"Тип сортировки: {(radioButtonInsertion.Checked ? "Сортировка вставками" : "Сортировка Шелла")}\n\n";

                    int iteration = 1;
                    int stepIndex = 0;

                    while (stepIndex < ComparativeAnalysis.SortSteps.Count)
                    {
                        string step = ComparativeAnalysis.SortSteps[stepIndex];

                        if (step.StartsWith("Сравнение:"))
                        {
                            content += $"\n{iteration} итерация:\n";
                            string comparison = step.Replace("Сравнение: ", "").Replace(">", "и");
                            content += $"Сравниваем {comparison}\n";

                            if (stepIndex + 1 < ComparativeAnalysis.SortSteps.Count &&
                                ComparativeAnalysis.SortSteps[stepIndex + 1].StartsWith("Состояние:"))
                            {
                                content += $"Перестановка {comparison}\n";
                                string arrayState = ComparativeAnalysis.SortSteps[stepIndex + 1].Replace("Состояние: ", "");
                                content += arrayState + "\n";
                                stepIndex += 2;
                            }
                            else
                            {
                                stepIndex++;
                            }

                            iteration++;
                        }
                        else
                        {
                            stepIndex++;
                        }
                    }

                    content += "\nРезультат сортировки:\n";
                    content += string.Join(" ", Context.array) + "\n\n";

                    content += $"Всего сравнений: {ComparativeAnalysis.Comparison}\n";
                    content += $"Всего перестановок: {ComparativeAnalysis.NumberOfPermutations}\n";
                    content += $"Время сортировки: {labelTime.Text}\n";

                    System.IO.File.WriteAllText(saveFileDialog.FileName, content);
                    MessageBox.Show($"Данные сохранены в файл:\n{saveFileDialog.FileName}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения файла: {ex.Message}");
            }
        }

        private void UpdateUI(string header)
        {
            TextBoxArray.Clear();
            if (!string.IsNullOrEmpty(header))
            {
                TextBoxArray.AppendText(header + " ");
            }
            TextBoxArray.AppendText(string.Join(" ", Context.array) + "\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            labelComparisons.Text = "Сравнений:";
            labelSwaps.Text = "Перестановок:";
            labelTime.Text = "Время:";
            TextBoxArray.Clear();
            ComparativeAnalysis.Reset();
            isArrayGenerated = false;
            buttonSort.Enabled = false;
            buttonSave.Enabled = false;
            buttonLoad.Enabled = false;
        }

        private void buttonAnaliz_Click(object sender, EventArgs e)
        {
            SravnitelniyAnaliz form = new SravnitelniyAnaliz();
            form.Show();
            Hide();

        }
    }
}
