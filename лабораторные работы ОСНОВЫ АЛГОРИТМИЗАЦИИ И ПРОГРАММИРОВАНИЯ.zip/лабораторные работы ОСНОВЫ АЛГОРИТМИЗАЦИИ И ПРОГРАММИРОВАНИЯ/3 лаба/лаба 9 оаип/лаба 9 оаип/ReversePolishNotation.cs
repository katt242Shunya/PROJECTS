﻿using MyLib;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace лаба_9_оаип
{
    public static class ReversePolishNotation
    {
        public static bool CalculateRPN(string expression)
        {
            string[] elements = expression.Split('.');
            string command = elements.LastOrDefault();

            switch (command)
            {
                case "R":
                    if (elements.Length != 6) // x.y.w.h.name.R
                    {
                        MessageBox.Show("неверный формат команды создания прямоугольника, нужен формат записи x.y.w.h.name.R");
                        return false;
                    }
                    break;
                case "M":
                    if (elements.Length != 4) // dx.dy.name.M
                    {
                        MessageBox.Show("неверный формат команды перемещения, нужен формат записи dx.dy.name.M");
                        return false;
                    }
                    break;
                case "D":
                    if (elements.Length != 2) // name.D
                    {
                        MessageBox.Show("неверный формат команды удаления, нужен формат записи name.D");
                        return false;
                    }
                    break;
                default:
                    MessageBox.Show("неизвестная команда");
                    return false;
            }

            Stack<object> operandsStack = new Stack<object>();
            foreach (string element in elements)
            {
                if (element == "R" || element == "M" || element == "D")
                {
                    if (!ApplyOperation(operandsStack, element))
                    {
                        return false;
                    }
                }
                else if (int.TryParse(element, out int number))
                {
                    operandsStack.Push(number);
                }
                else
                {
                    operandsStack.Push(element);
                }
            }
            return true;
        }



        private static bool IsOperator(string element)
        {
            return element == "R" || element == "M" || element == "D";
        }

        private static bool ApplyOperation(Stack<object> operands, string op)
        {
            try
            {
                if (op == "R" && operands.Count == 5)
                {
                    string name = operands.Pop().ToString();
                    int h = (int)operands.Pop();
                    int w = (int)operands.Pop();
                    int y = (int)operands.Pop();
                    int x = (int)operands.Pop();


                    if (ShapeContainer.figureList.Any(f => f.Name == name))
                    {
                        throw new ArgumentException($"Фигура с именем '{name}' уже существует");
                    }
                    if (w <= 0 || h <= 0)
                    {
                        throw new ArgumentException("Ширина и высота должны быть положительными числами");
                    }
                    if (x < 0 || y < 0 || x + w > Init.pictureBoxWidth || y + h > Init.pictureBoxHeight)
                    {
                        throw new ArgumentOutOfRangeException(
                            $"Фигура выходит за границы PictureBox");
                    }


                    RectangleFigure rect = new RectangleFigure(x, y, w, h, name);
                    ShapeContainer.AddFigure(rect);

                    using (Graphics g = Graphics.FromImage(Init.bitmap))
                    {
                        Init.ClearBitmap();
                        ShapeContainer.DrawAll(g);
                    }
                    Init.UpdatePictureBox();
                }
                else if (op == "M" && operands.Count == 3)
                {
                    string name = operands.Pop().ToString();
                    int dy = (int)operands.Pop();
                    int dx = (int)operands.Pop();

                    FigureClass fig = ShapeContainer.figureList.FirstOrDefault(f => f.Name == name);
                    if (fig == null)
                    {
                        throw new KeyNotFoundException($"Фигура с именем '{name}' не найдена");
                    }

                    int newX = fig.x + dx;
                    int newY = fig.y + dy;

                    if (newX < 0 || newY < 0 ||
                        newX + fig.w > Init.pictureBoxWidth ||
                        newY + fig.h > Init.pictureBoxHeight)
                    {
                        throw new ArgumentOutOfRangeException(
                            $"Невозможно переместить фигуру  она выйдет за границы");
                    }

                    fig.MoveTo(newX, newY);
                    using (Graphics g = Graphics.FromImage(Init.bitmap))
                    {
                        Init.ClearBitmap();
                        ShapeContainer.DrawAll(g);
                    }
                    Init.UpdatePictureBox();
                }
                else if (op == "D" && operands.Count == 1)
                {
                    string name = operands.Pop().ToString();
                    FigureClass fig = ShapeContainer.figureList.FirstOrDefault(f => f.Name == name);
                    if (fig == null)
                    {
                        throw new KeyNotFoundException($"Фигура с именем '{name}' не найдена");
                    }

                    ShapeContainer.RemoveFigure(fig);
                    using (Graphics g = Graphics.FromImage(Init.bitmap))
                    {
                        Init.ClearBitmap();
                        ShapeContainer.DrawAll(g);
                    }
                    Init.UpdatePictureBox();
                }
                else
                {
                    throw new InvalidOperationException("Некорректная команда или количество параметров");
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка выполнения команды",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}
