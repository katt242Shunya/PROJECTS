using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLib;

namespace лаба_9_оаип
{
    public partial class FormForPolishNotation : Form
    {
        private void InitializePictureBox()
        {
            Init.Initialize(pictureBoxRectangle, pictureBoxRectangle.Width, pictureBoxRectangle.Height);
            Init.ClearBitmap();
        }
        public FormForPolishNotation()
        {
            InitializeComponent();
            InitializePictureBox();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    string command = textBoxForCommand.Text;
                    if (ReversePolishNotation.CalculateRPN(command))
                    {
                        listBoxForComands.Items.Add("успех: " + command);
                    }
                    else
                    {
                        listBoxForComands.Items.Add("ошибочка: " + command);
                    }
                }
                catch (Exception ex)
                {
                    listBoxForComands.Items.Add("ошибочка: " + ex.Message);
                }
            }
        }
    }
}
