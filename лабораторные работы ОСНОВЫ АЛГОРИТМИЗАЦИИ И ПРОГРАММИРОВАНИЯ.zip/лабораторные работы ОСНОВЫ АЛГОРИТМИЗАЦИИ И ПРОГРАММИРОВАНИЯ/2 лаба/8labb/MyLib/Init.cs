﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyLib
{
    public class Init
    {

        public static Bitmap bitmap = new Bitmap(1, 1);
        public static PictureBox pictureBox;
        public static Pen pen = new Pen(Color.Black);
        public static int pictureBoxWidth;
        public static int pictureBoxHeight;

        public static void Initialize(PictureBox pb, int width, int height)
        {
            pictureBox = pb;
            bitmap = new Bitmap(width, height);
            pictureBoxWidth = width;
            pictureBoxHeight = height;
            pictureBox.Image = bitmap; 
        }

        public static void ClearBitmap()
        {
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(Color.White);
            }
            pictureBox.Image = bitmap;
        }

        public static void UpdatePictureBox()
        {
            pictureBox.Image = bitmap;
        }
    }
}