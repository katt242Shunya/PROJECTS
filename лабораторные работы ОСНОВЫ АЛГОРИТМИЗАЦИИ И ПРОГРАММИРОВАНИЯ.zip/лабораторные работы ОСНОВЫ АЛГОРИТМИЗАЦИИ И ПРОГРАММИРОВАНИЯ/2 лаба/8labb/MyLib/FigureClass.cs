﻿using System.Drawing;

namespace MyLib
{
    public abstract class FigureClass
    {
        public int x;
        public int y;
        public int w;
        public int h;
        public bool IsSelected { get; set; }
        public string Name { get; set; } 

        public abstract void Draw(Graphics g);
        public abstract void MoveTo(int x, int y);
        public abstract void Resize(int w, int h);
        public abstract bool Contains(int x, int y);
    }
}