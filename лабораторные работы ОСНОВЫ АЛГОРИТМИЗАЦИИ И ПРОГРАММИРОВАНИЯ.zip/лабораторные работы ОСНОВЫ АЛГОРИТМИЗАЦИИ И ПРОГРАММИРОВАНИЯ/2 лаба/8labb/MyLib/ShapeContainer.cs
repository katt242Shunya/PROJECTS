﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class ShapeContainer
    {
        public static List<FigureClass> figureList = new List<FigureClass>();

        public static void AddFigure(FigureClass figure)
        {
            figureList.Add(figure);
        }

        public static void RemoveFigure(FigureClass figure)
        {
            figureList.Remove(figure);
        }

        public static void DrawAll(Graphics g)
        {
            foreach (var figure in figureList)
            {
                figure.Draw(g);
            }
        }
    }
}