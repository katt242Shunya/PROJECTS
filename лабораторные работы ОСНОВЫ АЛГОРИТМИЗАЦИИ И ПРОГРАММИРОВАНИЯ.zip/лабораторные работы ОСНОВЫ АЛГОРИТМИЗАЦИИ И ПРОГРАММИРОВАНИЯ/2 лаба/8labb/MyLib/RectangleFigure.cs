﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class RectangleFigure : FigureClass
    {
        public RectangleFigure(int x, int y, int w, int h, string name)
        {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.Name = name;
            IsSelected = false;
        }

        public RectangleFigure() : this(0, 0, 0, 0, "") { }

        public override void Draw(Graphics g)
        {
            Color fillColor = IsSelected ? Color.Green : Color.Yellow;

            using (SolidBrush brush = new SolidBrush(fillColor))
            {
                g.FillRectangle(brush, this.x, this.y, this.w, this.h);
            }

            g.DrawRectangle(new Pen(Color.Black), this.x, this.y, this.w, this.h);
        }

        public override void MoveTo(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public override void Resize(int w, int h)
        {
            this.w = w;
            this.h = h;
        }

        public override bool Contains(int x, int y)
        {
            return (x >= this.x && x <= this.x + this.w && y >= this.y && y <= this.y + this.h);
        }
    }
}