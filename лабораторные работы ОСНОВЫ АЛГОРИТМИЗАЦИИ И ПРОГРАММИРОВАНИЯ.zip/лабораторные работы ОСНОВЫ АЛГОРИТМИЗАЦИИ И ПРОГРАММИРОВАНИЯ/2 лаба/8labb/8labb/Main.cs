﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;
using MyLib;

namespace _8labb
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void ToDrawRectangle_Click(object sender, EventArgs e)
        {

            Rectangle rectangle = new Rectangle();
            rectangle.Show();
            Hide();
        }

        private void ToDrawSquare_Click(object sender, EventArgs e)
        {

            Square square = new Square();
            square.Show();
            Hide();

        }

        private void ToDrawEllipse_Click(object sender, EventArgs e)
        {

            Ellipse ellipse = new Ellipse();
            ellipse.Show();
            Hide();

        }

        private void ToDrawCircle_Click(object sender, EventArgs e)
        {

            Circle circle = new Circle();
            circle.Show();
            Hide();
        }

        private void ToDrawTree_Click(object sender, EventArgs e)
        {
            ChristmasTree christmasTree = new ChristmasTree();
            christmasTree.Show();
            Hide();
        }

        private void ToDrawTriangle_Click(object sender, EventArgs e)
        {
            Triangle triangle = new Triangle();
            triangle.Show();
            Hide();
        }

        private void ToDrawPolygon_Click(object sender, EventArgs e)
        {
            Polygon polygon = new Polygon();
            polygon.Show();
            Hide();
        }
    }
}
