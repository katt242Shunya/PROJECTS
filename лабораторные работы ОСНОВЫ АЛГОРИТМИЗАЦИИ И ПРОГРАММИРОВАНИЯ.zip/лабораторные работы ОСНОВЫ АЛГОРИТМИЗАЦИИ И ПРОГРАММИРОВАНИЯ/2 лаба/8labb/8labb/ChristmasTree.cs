﻿using MyLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8labb
{
    public partial class ChristmasTree : Form
    {
        private List<ChristmasTreeFigure> trees = new List<ChristmasTreeFigure>(); 
        private ChristmasTreeFigure selectedTree = null; 

        public ChristmasTree()
        {
            InitializeComponent();
        }

        private void ChristmasTree_Load(object sender, EventArgs e)
        {
            Init.Initialize(pictureBoxForChristmasTree, pictureBoxForChristmasTree.Width, pictureBoxForChristmasTree.Height);
            textBoxMoveX.Enabled = false;
            textBoxMoveY.Enabled = false;
            buttonMoveTree.Enabled = false;
        }

        private void RedrawAll()
        {
            Init.ClearBitmap();
            using (Graphics g = Graphics.FromImage(Init.bitmap))
            {
                foreach (ChristmasTreeFigure tree in trees)
                {
                    tree.Draw(g);
                }
            }
            Init.UpdatePictureBox();
        }

        private void ButtonDrawTree_Click(object sender, EventArgs e)
        {
            int x, y, trunkWidth, trunkHeight, triangleBaseWidth, triangleHeight, circleRadius;

            if (!int.TryParse(textBoxX.Text, out x) ||
                !int.TryParse(textBoxY.Text, out y) ||
                !int.TryParse(textBoxTrunkWidth.Text, out trunkWidth) ||
                !int.TryParse(textBoxTrunkHeight.Text, out trunkHeight) ||
                !int.TryParse(textBoxTriangleBaseWidth.Text, out triangleBaseWidth) ||
                !int.TryParse(textBoxTriangleHeight.Text, out triangleHeight) ||
                !int.TryParse(textBoxCircleRadius.Text, out circleRadius))
            {
                MessageBox.Show("Введите корректные *целые* значения для всех параметров ёлки.");
                return; 
            }

            trunkWidth = Math.Min(trunkWidth, pictureBoxForChristmasTree.Width);
            trunkHeight = Math.Min(trunkHeight, pictureBoxForChristmasTree.Height);
            triangleBaseWidth = Math.Min(triangleBaseWidth, pictureBoxForChristmasTree.Width);
            triangleHeight = Math.Min(triangleHeight, pictureBoxForChristmasTree.Height);
            circleRadius = Math.Min(circleRadius, Math.Min(pictureBoxForChristmasTree.Width, pictureBoxForChristmasTree.Height));

            PointF location = new PointF(x, y);
            ChristmasTreeFigure tree = new ChristmasTreeFigure(location, trunkWidth, trunkHeight, triangleBaseWidth, triangleHeight, circleRadius);

            int minY = (int)location.Y - triangleHeight * 4 - circleRadius * 2; 
            int maxY = (int)location.Y + trunkHeight; 
            int minX = (int)location.X - triangleBaseWidth / 2; 
            int maxX = (int)location.X + trunkWidth + triangleBaseWidth / 2; 

            int deltaX = 0;
            int deltaY = 0;

            if (minX < 0)
            {
                deltaX = -minX; 
            }
            else if (maxX > pictureBoxForChristmasTree.Width)
            {
                deltaX = pictureBoxForChristmasTree.Width - maxX;
            }

            if (minY < 0)
            {
                deltaY = -minY; 
            }
            else if (maxY > pictureBoxForChristmasTree.Height)
            {
                deltaY = pictureBoxForChristmasTree.Height - maxY; 
            }

            location = new PointF(location.X + deltaX, location.Y + deltaY);
            tree.Location = location;

            trees.Add(tree);
            selectedTree = tree;
            RedrawAll();

            textBoxMoveX.Enabled = true;
            textBoxMoveY.Enabled = true;
            buttonMoveTree.Enabled = true;
        }

        private void ButtonMoveTree_Click(object sender, EventArgs e)
        {
            if (selectedTree == null)
            {
                MessageBox.Show("Сначала выберите ёлку для перемещения.");
                return;
            }

            int moveX, moveY;
            if (string.IsNullOrEmpty(textBoxMoveX.Text) || string.IsNullOrEmpty(textBoxMoveY.Text))
            {
                MessageBox.Show("Введите координаты для перемещения");
                return;
            }

            if (!int.TryParse(textBoxMoveX.Text, out moveX) || !int.TryParse(textBoxMoveY.Text, out moveY))
            {
                MessageBox.Show("Некорректные координаты");
                return;
            }
            int triangleHeight = selectedTree.TriangleHeight;
            int circleRadius = selectedTree.CircleRadius;
            int trunkWidth = selectedTree.TrunkWidth;
            int trunkHeight = selectedTree.TrunkHeight;
            int triangleBaseWidth = selectedTree.TriangleBaseWidth;
            PointF location = selectedTree.Location;

            int minY = (int)location.Y - triangleHeight * 4 - circleRadius * 2;
            int maxY = (int)location.Y + trunkHeight;
            int minX = (int)location.X - triangleBaseWidth / 2; 
            int maxX = (int)location.X + trunkWidth + triangleBaseWidth / 2; 

            int deltaX = 0;
            int deltaY = 0;

            if (minX + moveX < 0)
            {
                deltaX = -minX; 
            }
            else if (maxX + moveX > pictureBoxForChristmasTree.Width)
            {
                deltaX = pictureBoxForChristmasTree.Width - maxX; 
            }
            else
            {
                deltaX = moveX; 
            }
            if (minY + moveY < 0)
            {
                deltaY = -minY; 
            }
            else if (maxY + moveY > pictureBoxForChristmasTree.Height)
            {
                deltaY = pictureBoxForChristmasTree.Height - maxY; 
            }
            else
            {
                deltaY = moveY; 
            }
            selectedTree.MoveTo(selectedTree.x + deltaX, selectedTree.y + deltaY);
            RedrawAll();
        }




        private void ButtonRemoveTree_Click(object sender, EventArgs e)
        {
            if (selectedTree == null)
            {
                MessageBox.Show("Сначала выберите ёлку для удаления.");
                return;
            }
            trees.Remove(selectedTree);
            selectedTree = null;
            RedrawAll();
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            trees.Clear();
            Init.ClearBitmap();
            Init.UpdatePictureBox();
        }

        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (ChristmasTreeFigure tree in trees)
            {
                tree.IsSelected = false;
            }

            selectedTree = null;
            foreach (ChristmasTreeFigure tree in trees)
            {
                if (tree.Contains(e.X, e.Y))
                {
                    selectedTree = tree;
                    tree.IsSelected = true;
                    break;
                }
            }
            //RedrawAll();
        }

        private void BackToMain_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();

            Main main = new Main();
            main.Show();
            Hide();
        }
    }

}
