﻿namespace _8labb
{
    partial class Polygon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxForPolygon = new PictureBox();
            groupBoxForPolygon = new GroupBox();
            BackToMain = new Button();
            label1 = new Label();
            buttonClear = new Button();
            buttonRemovePolygon = new Button();
            buttonMovePolygon = new Button();
            labelForY = new Label();
            labelForX = new Label();
            buttonDrawPolygon = new Button();
            buttonCreatePoint = new Button();
            labelForNewY = new Label();
            labelForNewX = new Label();
            labelForPoints = new Label();
            textBoxMoveY = new TextBox();
            textBoxMoveX = new TextBox();
            textBoxCoordY = new TextBox();
            textBoxCoordX = new TextBox();
            textBoxNumPoints = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForPolygon).BeginInit();
            groupBoxForPolygon.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBoxForPolygon
            // 
            pictureBoxForPolygon.Location = new Point(682, 23);
            pictureBoxForPolygon.Name = "pictureBoxForPolygon";
            pictureBoxForPolygon.Size = new Size(492, 539);
            pictureBoxForPolygon.TabIndex = 0;
            pictureBoxForPolygon.TabStop = false;
            pictureBoxForPolygon.MouseClick += PictureBox1_MouseClick;
            // 
            // groupBoxForPolygon
            // 
            groupBoxForPolygon.Controls.Add(BackToMain);
            groupBoxForPolygon.Controls.Add(label1);
            groupBoxForPolygon.Controls.Add(buttonClear);
            groupBoxForPolygon.Controls.Add(buttonRemovePolygon);
            groupBoxForPolygon.Controls.Add(buttonMovePolygon);
            groupBoxForPolygon.Controls.Add(labelForY);
            groupBoxForPolygon.Controls.Add(labelForX);
            groupBoxForPolygon.Controls.Add(buttonDrawPolygon);
            groupBoxForPolygon.Controls.Add(buttonCreatePoint);
            groupBoxForPolygon.Controls.Add(labelForNewY);
            groupBoxForPolygon.Controls.Add(labelForNewX);
            groupBoxForPolygon.Controls.Add(labelForPoints);
            groupBoxForPolygon.Controls.Add(textBoxMoveY);
            groupBoxForPolygon.Controls.Add(textBoxMoveX);
            groupBoxForPolygon.Controls.Add(textBoxCoordY);
            groupBoxForPolygon.Controls.Add(textBoxCoordX);
            groupBoxForPolygon.Controls.Add(textBoxNumPoints);
            groupBoxForPolygon.Font = new Font("Microsoft JhengHei", 9F);
            groupBoxForPolygon.Location = new Point(12, 12);
            groupBoxForPolygon.Name = "groupBoxForPolygon";
            groupBoxForPolygon.Size = new Size(653, 550);
            groupBoxForPolygon.TabIndex = 1;
            groupBoxForPolygon.TabStop = false;
            groupBoxForPolygon.Text = "рисуем многоугольник!";
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(6, 491);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 22;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 196);
            label1.Name = "label1";
            label1.Size = new Size(17, 19);
            label1.TabIndex = 15;
            label1.Text = "  ";
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(348, 467);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(295, 29);
            buttonClear.TabIndex = 14;
            buttonClear.Text = "Удалить все фигуры";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += ButtonClear_Click;
            // 
            // buttonRemovePolygon
            // 
            buttonRemovePolygon.Location = new Point(405, 432);
            buttonRemovePolygon.Name = "buttonRemovePolygon";
            buttonRemovePolygon.Size = new Size(242, 29);
            buttonRemovePolygon.TabIndex = 13;
            buttonRemovePolygon.Text = "Удалить многоугольник";
            buttonRemovePolygon.UseVisualStyleBackColor = true;
            buttonRemovePolygon.Click += ButtonRemovePolygon_Click;
            // 
            // buttonMovePolygon
            // 
            buttonMovePolygon.Location = new Point(348, 34);
            buttonMovePolygon.Name = "buttonMovePolygon";
            buttonMovePolygon.Size = new Size(216, 29);
            buttonMovePolygon.TabIndex = 12;
            buttonMovePolygon.Text = "Переместить фигуру!";
            buttonMovePolygon.UseVisualStyleBackColor = true;
            buttonMovePolygon.Click += ButtonMovePolygon_Click;
            // 
            // labelForY
            // 
            labelForY.AutoSize = true;
            labelForY.Location = new Point(6, 317);
            labelForY.Name = "labelForY";
            labelForY.Size = new Size(202, 19);
            labelForY.TabIndex = 11;
            labelForY.Text = "Введите координаты для Y:";
            // 
            // labelForX
            // 
            labelForX.AutoSize = true;
            labelForX.Font = new Font("Microsoft JhengHei", 9F);
            labelForX.Location = new Point(6, 272);
            labelForX.Name = "labelForX";
            labelForX.Size = new Size(203, 19);
            labelForX.TabIndex = 10;
            labelForX.Text = "Введите координаты для X:";
            // 
            // buttonDrawPolygon
            // 
            buttonDrawPolygon.Location = new Point(6, 362);
            buttonDrawPolygon.Name = "buttonDrawPolygon";
            buttonDrawPolygon.Size = new Size(269, 29);
            buttonDrawPolygon.TabIndex = 9;
            buttonDrawPolygon.Text = "Нарисовать многоугольник";
            buttonDrawPolygon.UseVisualStyleBackColor = true;
            buttonDrawPolygon.Click += ButtonDrawPolygon_Click;
            // 
            // buttonCreatePoint
            // 
            buttonCreatePoint.Location = new Point(6, 125);
            buttonCreatePoint.Name = "buttonCreatePoint";
            buttonCreatePoint.Size = new Size(174, 29);
            buttonCreatePoint.TabIndex = 8;
            buttonCreatePoint.Text = "Создать точку";
            buttonCreatePoint.UseVisualStyleBackColor = true;
            buttonCreatePoint.Click += ButtonCreatePoint_Click;
            // 
            // labelForNewY
            // 
            labelForNewY.AutoSize = true;
            labelForNewY.Location = new Point(269, 121);
            labelForNewY.Name = "labelForNewY";
            labelForNewY.Size = new Size(250, 19);
            labelForNewY.TabIndex = 7;
            labelForNewY.Text = "Введите новые координаты для Y:";
            // 
            // labelForNewX
            // 
            labelForNewX.AutoSize = true;
            labelForNewX.Location = new Point(269, 83);
            labelForNewX.Name = "labelForNewX";
            labelForNewX.Size = new Size(251, 19);
            labelForNewX.TabIndex = 6;
            labelForNewX.Text = "Введите новые координаты для X:";
            // 
            // labelForPoints
            // 
            labelForPoints.AutoSize = true;
            labelForPoints.Location = new Point(6, 33);
            labelForPoints.Name = "labelForPoints";
            labelForPoints.Size = new Size(277, 38);
            labelForPoints.TabIndex = 5;
            labelForPoints.Text = "Введите желаемое количество точек \r\n(не менее трех)";
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(522, 118);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(125, 27);
            textBoxMoveY.TabIndex = 4;
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(522, 76);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(125, 27);
            textBoxMoveX.TabIndex = 3;
            // 
            // textBoxCoordY
            // 
            textBoxCoordY.Location = new Point(209, 314);
            textBoxCoordY.Name = "textBoxCoordY";
            textBoxCoordY.Size = new Size(125, 27);
            textBoxCoordY.TabIndex = 2;
            // 
            // textBoxCoordX
            // 
            textBoxCoordX.Location = new Point(210, 269);
            textBoxCoordX.Name = "textBoxCoordX";
            textBoxCoordX.Size = new Size(125, 27);
            textBoxCoordX.TabIndex = 1;
            // 
            // textBoxNumPoints
            // 
            textBoxNumPoints.Location = new Point(6, 76);
            textBoxNumPoints.Name = "textBoxNumPoints";
            textBoxNumPoints.Size = new Size(125, 27);
            textBoxNumPoints.TabIndex = 0;
            // 
            // Polygon
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1186, 574);
            Controls.Add(groupBoxForPolygon);
            Controls.Add(pictureBoxForPolygon);
            Name = "Polygon";
            Text = "Polygon";
            Load += Polygon_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxForPolygon).EndInit();
            groupBoxForPolygon.ResumeLayout(false);
            groupBoxForPolygon.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBoxForPolygon;
        private GroupBox groupBoxForPolygon;
        private Button buttonClear;
        private Button buttonRemovePolygon;
        private Button buttonMovePolygon;
        private Label labelForY;
        private Label labelForX;
        private Button buttonDrawPolygon;
        private Button buttonCreatePoint;
        private Label labelForNewY;
        private Label labelForNewX;
        private Label labelForPoints;
        private TextBox textBoxMoveY;
        private TextBox textBoxMoveX;
        private TextBox textBoxCoordY;
        private TextBox textBoxCoordX;
        private TextBox textBoxNumPoints;
        private Label label1;
        private Button BackToMain;
    }
}