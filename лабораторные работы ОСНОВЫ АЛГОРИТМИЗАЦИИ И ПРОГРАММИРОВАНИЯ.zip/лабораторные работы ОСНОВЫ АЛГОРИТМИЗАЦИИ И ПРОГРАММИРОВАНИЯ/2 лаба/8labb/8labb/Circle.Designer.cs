﻿namespace _8labb
{
    partial class Circle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            drawRec = new GroupBox();
            BackToMain = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBoxResizeRadius = new TextBox();
            textBoxMoveY = new TextBox();
            textBoxMoveX = new TextBox();
            textBoxRadius = new TextBox();
            textBoxCircleY = new TextBox();
            textBoxCircleX = new TextBox();
            buttonClear = new Button();
            buttonRemoveCircle = new Button();
            buttonResizeCircle = new Button();
            buttonMoveCircle = new Button();
            buttonDrawCircle = new Button();
            pictureBoxForCircle = new PictureBox();
            drawRec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForCircle).BeginInit();
            SuspendLayout();
            // 
            // drawRec
            // 
            drawRec.Controls.Add(BackToMain);
            drawRec.Controls.Add(label7);
            drawRec.Controls.Add(label6);
            drawRec.Controls.Add(label5);
            drawRec.Controls.Add(label3);
            drawRec.Controls.Add(label2);
            drawRec.Controls.Add(label1);
            drawRec.Controls.Add(textBoxResizeRadius);
            drawRec.Controls.Add(textBoxMoveY);
            drawRec.Controls.Add(textBoxMoveX);
            drawRec.Controls.Add(textBoxRadius);
            drawRec.Controls.Add(textBoxCircleY);
            drawRec.Controls.Add(textBoxCircleX);
            drawRec.Controls.Add(buttonClear);
            drawRec.Controls.Add(buttonRemoveCircle);
            drawRec.Controls.Add(buttonResizeCircle);
            drawRec.Controls.Add(buttonMoveCircle);
            drawRec.Controls.Add(buttonDrawCircle);
            drawRec.Font = new Font("Microsoft JhengHei", 9F);
            drawRec.Location = new Point(8, 16);
            drawRec.Margin = new Padding(3, 4, 3, 4);
            drawRec.Name = "drawRec";
            drawRec.Padding = new Padding(3, 4, 3, 4);
            drawRec.Size = new Size(921, 761);
            drawRec.TabIndex = 5;
            drawRec.TabStop = false;
            drawRec.Text = "draw circle!";
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(7, 715);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 22;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(18, 473);
            label7.Name = "label7";
            label7.Size = new Size(241, 19);
            label7.TabIndex = 19;
            label7.Text = "Введите новое значение радиуса";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(522, 308);
            label6.Name = "label6";
            label6.Size = new Size(245, 19);
            label6.TabIndex = 18;
            label6.Text = "Введите новые координаты для у";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(522, 244);
            label5.Name = "label5";
            label5.Size = new Size(245, 19);
            label5.TabIndex = 17;
            label5.Text = "Введите новые координаты для х";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 236);
            label3.Name = "label3";
            label3.Size = new Size(195, 19);
            label3.TabIndex = 15;
            label3.Text = "Введите значение радиуса";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 176);
            label2.Name = "label2";
            label2.Size = new Size(197, 19);
            label2.TabIndex = 14;
            label2.Text = "Введите координаты для у";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 125);
            label1.Name = "label1";
            label1.Size = new Size(197, 19);
            label1.TabIndex = 13;
            label1.Text = "Введите координаты для х";
            // 
            // textBoxResizeRadius
            // 
            textBoxResizeRadius.Location = new Point(255, 469);
            textBoxResizeRadius.Margin = new Padding(3, 4, 3, 4);
            textBoxResizeRadius.Name = "textBoxResizeRadius";
            textBoxResizeRadius.Size = new Size(114, 27);
            textBoxResizeRadius.TabIndex = 11;
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(762, 304);
            textBoxMoveY.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(114, 27);
            textBoxMoveY.TabIndex = 10;
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(762, 240);
            textBoxMoveX.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(114, 27);
            textBoxMoveX.TabIndex = 9;
            // 
            // textBoxRadius
            // 
            textBoxRadius.Location = new Point(213, 235);
            textBoxRadius.Margin = new Padding(3, 4, 3, 4);
            textBoxRadius.Name = "textBoxRadius";
            textBoxRadius.Size = new Size(114, 27);
            textBoxRadius.TabIndex = 7;
            // 
            // textBoxCircleY
            // 
            textBoxCircleY.Location = new Point(213, 172);
            textBoxCircleY.Margin = new Padding(3, 4, 3, 4);
            textBoxCircleY.Name = "textBoxCircleY";
            textBoxCircleY.Size = new Size(114, 27);
            textBoxCircleY.TabIndex = 6;
            // 
            // textBoxCircleX
            // 
            textBoxCircleX.Location = new Point(213, 121);
            textBoxCircleX.Margin = new Padding(3, 4, 3, 4);
            textBoxCircleX.Name = "textBoxCircleX";
            textBoxCircleX.Size = new Size(114, 27);
            textBoxCircleX.TabIndex = 5;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = Color.FromArgb(255, 128, 128);
            buttonClear.Location = new Point(775, 696);
            buttonClear.Margin = new Padding(3, 4, 3, 4);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(127, 55);
            buttonClear.TabIndex = 4;
            buttonClear.Text = "очистить все";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonRemoveCircle
            // 
            buttonRemoveCircle.BackColor = Color.FromArgb(192, 255, 192);
            buttonRemoveCircle.Location = new Point(669, 605);
            buttonRemoveCircle.Margin = new Padding(3, 4, 3, 4);
            buttonRemoveCircle.Name = "buttonRemoveCircle";
            buttonRemoveCircle.Size = new Size(233, 83);
            buttonRemoveCircle.TabIndex = 3;
            buttonRemoveCircle.Text = "удалить выбранный круг";
            buttonRemoveCircle.UseVisualStyleBackColor = false;
            buttonRemoveCircle.Click += buttonRemoveCircle_Click;
            // 
            // buttonResizeCircle
            // 
            buttonResizeCircle.BackColor = Color.FromArgb(224, 224, 224);
            buttonResizeCircle.Location = new Point(18, 383);
            buttonResizeCircle.Margin = new Padding(3, 4, 3, 4);
            buttonResizeCircle.Name = "buttonResizeCircle";
            buttonResizeCircle.Size = new Size(198, 65);
            buttonResizeCircle.TabIndex = 2;
            buttonResizeCircle.Text = "Изменить размер фигуры";
            buttonResizeCircle.UseVisualStyleBackColor = false;
            buttonResizeCircle.Click += buttonResizeCircle_Click;
            // 
            // buttonMoveCircle
            // 
            buttonMoveCircle.BackColor = SystemColors.ActiveCaption;
            buttonMoveCircle.Location = new Point(522, 156);
            buttonMoveCircle.Margin = new Padding(3, 4, 3, 4);
            buttonMoveCircle.Name = "buttonMoveCircle";
            buttonMoveCircle.Size = new Size(245, 53);
            buttonMoveCircle.TabIndex = 1;
            buttonMoveCircle.Text = "Сдвинуть фигуру";
            buttonMoveCircle.UseVisualStyleBackColor = false;
            buttonMoveCircle.Click += buttonMoveCircle_Click;
            // 
            // buttonDrawCircle
            // 
            buttonDrawCircle.BackColor = Color.FromArgb(255, 224, 192);
            buttonDrawCircle.Location = new Point(18, 49);
            buttonDrawCircle.Margin = new Padding(3, 4, 3, 4);
            buttonDrawCircle.Name = "buttonDrawCircle";
            buttonDrawCircle.Size = new Size(241, 53);
            buttonDrawCircle.TabIndex = 0;
            buttonDrawCircle.Text = "Нарисовать фигуру";
            buttonDrawCircle.UseVisualStyleBackColor = false;
            buttonDrawCircle.Click += buttonDrawCircle_Click;
            // 
            // pictureBoxForCircle
            // 
            pictureBoxForCircle.BackColor = Color.FromArgb(224, 224, 224);
            pictureBoxForCircle.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxForCircle.Location = new Point(969, 16);
            pictureBoxForCircle.Margin = new Padding(3, 4, 3, 4);
            pictureBoxForCircle.Name = "pictureBoxForCircle";
            pictureBoxForCircle.Size = new Size(556, 761);
            pictureBoxForCircle.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxForCircle.TabIndex = 4;
            pictureBoxForCircle.TabStop = false;
            pictureBoxForCircle.MouseClick += PictureBox1_MouseClick;
            // 
            // Circle
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1549, 792);
            Controls.Add(drawRec);
            Controls.Add(pictureBoxForCircle);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Circle";
            Text = "Circle";
            Load += Circle_Load;
            drawRec.ResumeLayout(false);
            drawRec.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForCircle).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox drawRec;
        private Button BackToMain;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBoxResizeRadius;
        private TextBox textBoxMoveY;
        private TextBox textBoxMoveX;
        private TextBox textBoxRadius;
        private TextBox textBoxCircleY;
        private TextBox textBoxCircleX;
        private Button buttonClear;
        private Button buttonRemoveCircle;
        private Button buttonResizeCircle;
        private Button buttonMoveCircle;
        private Button buttonDrawCircle;
        private PictureBox pictureBoxForCircle;
    }
}