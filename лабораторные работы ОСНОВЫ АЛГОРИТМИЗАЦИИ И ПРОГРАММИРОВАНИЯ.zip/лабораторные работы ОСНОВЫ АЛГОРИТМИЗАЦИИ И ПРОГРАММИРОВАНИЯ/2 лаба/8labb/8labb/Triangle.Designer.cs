﻿namespace _8labb
{
    partial class Triangle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBoxForTriangle = new GroupBox();
            label1 = new Label();
            BackToMain = new Button();
            buttonMoveTriangle = new Button();
            buttonClear = new Button();
            labelForY = new Label();
            buttonRemoveTriangle = new Button();
            labelForX = new Label();
            buttonDrawTriangle = new Button();
            buttonCreatePoint = new Button();
            textBoxCoordX = new TextBox();
            labelForNewY = new Label();
            textBoxCoordY = new TextBox();
            labelForNewX = new Label();
            textBoxMoveX = new TextBox();
            textBoxMoveY = new TextBox();
            pictureBoxForTriangle = new PictureBox();
            groupBoxForTriangle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForTriangle).BeginInit();
            SuspendLayout();
            // 
            // groupBoxForTriangle
            // 
            groupBoxForTriangle.Controls.Add(label1);
            groupBoxForTriangle.Controls.Add(BackToMain);
            groupBoxForTriangle.Controls.Add(buttonMoveTriangle);
            groupBoxForTriangle.Controls.Add(buttonClear);
            groupBoxForTriangle.Controls.Add(labelForY);
            groupBoxForTriangle.Controls.Add(buttonRemoveTriangle);
            groupBoxForTriangle.Controls.Add(labelForX);
            groupBoxForTriangle.Controls.Add(buttonDrawTriangle);
            groupBoxForTriangle.Controls.Add(buttonCreatePoint);
            groupBoxForTriangle.Controls.Add(textBoxCoordX);
            groupBoxForTriangle.Controls.Add(labelForNewY);
            groupBoxForTriangle.Controls.Add(textBoxCoordY);
            groupBoxForTriangle.Controls.Add(labelForNewX);
            groupBoxForTriangle.Controls.Add(textBoxMoveX);
            groupBoxForTriangle.Controls.Add(textBoxMoveY);
            groupBoxForTriangle.Font = new Font("Microsoft JhengHei", 9F);
            groupBoxForTriangle.Location = new Point(7, 12);
            groupBoxForTriangle.Name = "groupBoxForTriangle";
            groupBoxForTriangle.Size = new Size(783, 552);
            groupBoxForTriangle.TabIndex = 3;
            groupBoxForTriangle.TabStop = false;
            groupBoxForTriangle.Text = "рисуем треугольничек!!";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 48);
            label1.Name = "label1";
            label1.Size = new Size(17, 19);
            label1.TabIndex = 29;
            label1.Text = "  ";
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(24, 493);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 25;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // buttonMoveTriangle
            // 
            buttonMoveTriangle.Location = new Point(380, 276);
            buttonMoveTriangle.Name = "buttonMoveTriangle";
            buttonMoveTriangle.Size = new Size(216, 29);
            buttonMoveTriangle.TabIndex = 28;
            buttonMoveTriangle.Text = "Переместить фигуру!";
            buttonMoveTriangle.UseVisualStyleBackColor = true;
            buttonMoveTriangle.Click += ButtonMoveTriangle_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(471, 493);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(295, 29);
            buttonClear.TabIndex = 24;
            buttonClear.Text = "Удалить все фигуры";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += ButtonClear_Click;
            // 
            // labelForY
            // 
            labelForY.AutoSize = true;
            labelForY.Location = new Point(15, 175);
            labelForY.Name = "labelForY";
            labelForY.Size = new Size(202, 19);
            labelForY.TabIndex = 27;
            labelForY.Text = "Введите координаты для Y:";
            // 
            // buttonRemoveTriangle
            // 
            buttonRemoveTriangle.Location = new Point(510, 449);
            buttonRemoveTriangle.Name = "buttonRemoveTriangle";
            buttonRemoveTriangle.Size = new Size(242, 29);
            buttonRemoveTriangle.TabIndex = 23;
            buttonRemoveTriangle.Text = "Удалить треугольник((";
            buttonRemoveTriangle.UseVisualStyleBackColor = true;
            buttonRemoveTriangle.Click += ButtonRemoveTriangle_Click;
            // 
            // labelForX
            // 
            labelForX.AutoSize = true;
            labelForX.Location = new Point(15, 130);
            labelForX.Name = "labelForX";
            labelForX.Size = new Size(203, 19);
            labelForX.TabIndex = 26;
            labelForX.Text = "Введите координаты для X:";
            // 
            // buttonDrawTriangle
            // 
            buttonDrawTriangle.Location = new Point(35, 225);
            buttonDrawTriangle.Name = "buttonDrawTriangle";
            buttonDrawTriangle.Size = new Size(269, 29);
            buttonDrawTriangle.TabIndex = 25;
            buttonDrawTriangle.Text = "Нарисовать многоугольник";
            buttonDrawTriangle.UseVisualStyleBackColor = true;
            buttonDrawTriangle.Click += ButtonDrawTriangle_Click;
            // 
            // buttonCreatePoint
            // 
            buttonCreatePoint.Location = new Point(24, 87);
            buttonCreatePoint.Name = "buttonCreatePoint";
            buttonCreatePoint.Size = new Size(174, 29);
            buttonCreatePoint.TabIndex = 24;
            buttonCreatePoint.Text = "Создать точку";
            buttonCreatePoint.UseVisualStyleBackColor = true;
            buttonCreatePoint.Click += ButtonCreatePoint_Click;
            // 
            // textBoxCoordX
            // 
            textBoxCoordX.Location = new Point(219, 127);
            textBoxCoordX.Name = "textBoxCoordX";
            textBoxCoordX.Size = new Size(125, 27);
            textBoxCoordX.TabIndex = 17;
            // 
            // labelForNewY
            // 
            labelForNewY.AutoSize = true;
            labelForNewY.Location = new Point(301, 363);
            labelForNewY.Name = "labelForNewY";
            labelForNewY.Size = new Size(250, 19);
            labelForNewY.TabIndex = 23;
            labelForNewY.Text = "Введите новые координаты для Y:";
            // 
            // textBoxCoordY
            // 
            textBoxCoordY.Location = new Point(218, 172);
            textBoxCoordY.Name = "textBoxCoordY";
            textBoxCoordY.Size = new Size(125, 27);
            textBoxCoordY.TabIndex = 18;
            // 
            // labelForNewX
            // 
            labelForNewX.AutoSize = true;
            labelForNewX.Location = new Point(301, 325);
            labelForNewX.Name = "labelForNewX";
            labelForNewX.Size = new Size(251, 19);
            labelForNewX.TabIndex = 22;
            labelForNewX.Text = "Введите новые координаты для X:";
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(554, 318);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(125, 27);
            textBoxMoveX.TabIndex = 19;
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(554, 360);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(125, 27);
            textBoxMoveY.TabIndex = 20;
            // 
            // pictureBoxForTriangle
            // 
            pictureBoxForTriangle.Location = new Point(796, 12);
            pictureBoxForTriangle.Name = "pictureBoxForTriangle";
            pictureBoxForTriangle.Size = new Size(444, 552);
            pictureBoxForTriangle.TabIndex = 2;
            pictureBoxForTriangle.TabStop = false;
            pictureBoxForTriangle.MouseClick += PictureBox1_MouseClick;
            // 
            // Triangle
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1256, 577);
            Controls.Add(groupBoxForTriangle);
            Controls.Add(pictureBoxForTriangle);
            Name = "Triangle";
            Text = "Triangle";
            Load += Triangle_Load;
            groupBoxForTriangle.ResumeLayout(false);
            groupBoxForTriangle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForTriangle).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBoxForTriangle;
        private Button BackToMain;
        private Button buttonClear;
        private Button buttonRemoveTriangle;
        private PictureBox pictureBoxForTriangle;
        private Label label1;
        private Button buttonMoveTriangle;
        private Label labelForY;
        private Label labelForX;
        private Button buttonDrawTriangle;
        private Button buttonCreatePoint;
        private TextBox textBoxCoordX;
        private Label labelForNewY;
        private TextBox textBoxCoordY;
        private Label labelForNewX;
        private TextBox textBoxMoveX;
        private TextBox textBoxMoveY;
    }
}