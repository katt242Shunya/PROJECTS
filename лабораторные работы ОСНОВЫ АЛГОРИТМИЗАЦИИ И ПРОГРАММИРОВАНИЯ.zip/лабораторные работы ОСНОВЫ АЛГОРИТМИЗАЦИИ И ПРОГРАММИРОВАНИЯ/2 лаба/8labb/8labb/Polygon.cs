﻿using MyLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8labb
{
    public partial class Polygon : Form
    {
        private PolygonFigure currentPolygon = null;
        private PointF[] pointFs;
        private int numPoints;
        private int i = 0;
        private bool flag = false;

        public Polygon()
        {
            InitializeComponent();
        }

        private void Polygon_Load(object sender, EventArgs e)
        {
            Init.Initialize(pictureBoxForPolygon, pictureBoxForPolygon.Width, pictureBoxForPolygon.Height); 
            buttonDrawPolygon.Enabled = false;
            textBoxCoordX.Enabled = false;
            textBoxCoordY.Enabled = false;
        }

        private void RedrawAll()
        {
            Init.ClearBitmap();
            using (Graphics g = Graphics.FromImage(Init.bitmap))
            {
                ShapeContainer.DrawAll(g);
            }
            Init.UpdatePictureBox();
        }

        private void ButtonCreatePoint_Click(object sender, EventArgs e)
        {
            if (flag == false)
            {
                if (!int.TryParse(textBoxNumPoints.Text, out numPoints) || numPoints <= 2)
                {
                    MessageBox.Show("Введите корректное количество точек (минимум 3)");
                    return;
                }

                this.pointFs = new PointF[numPoints];
                flag = true;
                textBoxNumPoints.Enabled = false;
                textBoxCoordX.Enabled = true;
                textBoxCoordY.Enabled = true;
                label1.Text = $"Введите координаты {i + 1}й точки: ";
            }
            else
            {
                if (i != numPoints - 1)
                {
                    if (!float.TryParse(textBoxCoordX.Text, out float x) ||
                        !float.TryParse(textBoxCoordY.Text, out float y))
                    {
                        MessageBox.Show("Введите корректные координаты.");
                        return;
                    }

                    x = Math.Max(0, Math.Min(x, pictureBoxForPolygon.Width));
                    y = Math.Max(0, Math.Min(y, pictureBoxForPolygon.Height));

                    pointFs[i].X = x;
                    pointFs[i].Y = y;
                    i++;
                    label1.Text = $"Введите координаты {i + 1}й точки: ";
                    textBoxCoordX.Text = "";
                    textBoxCoordY.Text = "";
                }
                else
                {
                    if (!float.TryParse(textBoxCoordX.Text, out float x) ||
                        !float.TryParse(textBoxCoordY.Text, out float y))
                    {
                        MessageBox.Show("Введите корректные координаты");
                        return;
                    }

                    x = Math.Max(0, Math.Min(x, pictureBoxForPolygon.Width));
                    y = Math.Max(0, Math.Min(y, pictureBoxForPolygon.Height));

                    pointFs[i].X = x;
                    pointFs[i].Y = y;
                    buttonCreatePoint.Enabled = false;
                    buttonDrawPolygon.Enabled = true;
                    flag = false;
                }
            }
        }

        private void ButtonDrawPolygon_Click(object sender, EventArgs e)
        {
            PolygonFigure polygon = new PolygonFigure(pointFs);

            int minX = (int)pointFs[0].X, minY = (int)pointFs[0].Y;
            int maxX = (int)pointFs[0].X, maxY = (int)pointFs[0].Y;

            foreach (PointF point in pointFs)
            {
                minX = Math.Min(minX, (int)point.X);
                minY = Math.Min(minY, (int)point.Y);
                maxX = Math.Max(maxX, (int)point.X);
                maxY = Math.Max(maxY, (int)point.Y);
            }

            int width = maxX - minX;
            int height = maxY - minY;

            int deltaX = 0, deltaY = 0;

            if (minX < 0)
            {
                deltaX = -minX; 
            }
            else if (maxX > pictureBoxForPolygon.Width)
            {
                deltaX = pictureBoxForPolygon.Width - maxX; 
            }

            if (minY < 0)
            {
                deltaY = -minY; 
            }
            else if (maxY > pictureBoxForPolygon.Height)
            {
                deltaY = pictureBoxForPolygon.Height - maxY; 
            }

            if (deltaX != 0 || deltaY != 0)
            {
                for (int i = 0; i < pointFs.Length; i++)
                {
                    pointFs[i].X += deltaX;
                    pointFs[i].Y += deltaY;
                }
                polygon = new PolygonFigure(pointFs); 
            }

            ShapeContainer.AddFigure(polygon);
            RedrawAll();

            buttonCreatePoint.Enabled = true;
            buttonDrawPolygon.Enabled = false;
            textBoxCoordX.Enabled = false;
            textBoxCoordY.Enabled = false;
            textBoxNumPoints.Enabled = true;
            textBoxCoordX.Clear();
            textBoxCoordY.Clear();
            label1.Text = "";
            i = 0;
            flag = false;
        }
        private void ButtonMovePolygon_Click(object sender, EventArgs e)
        {
            int moveX, moveY;
            if (currentPolygon == null)
            {
                MessageBox.Show("Сначала выберите многоугольник");
                return;
            }

            if (string.IsNullOrEmpty(textBoxMoveX.Text) || string.IsNullOrEmpty(textBoxMoveY.Text))
            {
                MessageBox.Show("Введите координаты для перемещения");
                return;
            }

            if (!int.TryParse(textBoxMoveX.Text, out moveX) || !int.TryParse(textBoxMoveY.Text, out moveY))
            {
                MessageBox.Show("Некорректные координаты");
                return;
            }

            PointF[] points = currentPolygon.points;

            int minX = (int)points[0].X, minY = (int)points[0].Y;
            int maxX = (int)points[0].X, maxY = (int)points[0].Y;

            foreach (PointF point in points)
            {
                minX = Math.Min(minX, (int)point.X);
                minY = Math.Min(minY, (int)point.Y);
                maxX = Math.Max(maxX, (int)point.X);
                maxY = Math.Max(maxY, (int)point.Y);
            }

            int width = maxX - minX;
            int height = maxY - minY;

            int newX = minX + moveX;
            int newY = minY + moveY;

            if (newX < 0)
            {
                newX = 0; 
            }
            else if (newX + width > pictureBoxForPolygon.Width)
            {
                newX = pictureBoxForPolygon.Width - width; 
            }

            if (newY < 0)
            {
                newY = 0; 
            }
            else if (newY + height > pictureBoxForPolygon.Height)
            {
                newY = pictureBoxForPolygon.Height - height; 
            }


            if ((moveX < 0 && minX == 0) || (moveX > 0 && maxX == Init.pictureBoxWidth) || (moveY < 0 && minY == 0) || (moveY > 0 && maxY == Init.pictureBoxHeight))
            {
                MessageBox.Show("Перемещение больше недоступно эллипс достиг границы");
                return;
            }
            currentPolygon.MoveTo(newX, newY);
            RedrawAll();
        }
        private void ButtonRemovePolygon_Click(object sender, EventArgs e)
        {
            if (currentPolygon == null)
            {
                MessageBox.Show("выберите многоугольник");
                return;
            }

            ShapeContainer.RemoveFigure(currentPolygon);
            currentPolygon = null;
            RedrawAll();
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();
        }

        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (var figure in ShapeContainer.figureList)
            {
                figure.IsSelected = false;
            }

            for (int i = ShapeContainer.figureList.Count - 1; i >= 0; i--)
            {
                FigureClass figure = ShapeContainer.figureList[i];
                if (figure is PolygonFigure polygon && polygon.Contains(e.X, e.Y))
                {
                    currentPolygon = polygon;
                    currentPolygon.IsSelected = true;
                    RedrawAll();
                    return;
                }
            }
            currentPolygon = null;
            RedrawAll();
        }
        private void BackToMain_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();

            Main main = new Main();
            main.Show();
            Hide();
        }
    }
}
