﻿namespace _8labb
{
    partial class Square
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            drawRec = new GroupBox();
            BackToMain = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBoxResizeSide = new TextBox();
            textBoxMoveY = new TextBox();
            textBoxMoveX = new TextBox();
            textBoxSide = new TextBox();
            textBoxSquareY = new TextBox();
            textBoxSquareX = new TextBox();
            buttonClear = new Button();
            buttonRemoveSquare = new Button();
            buttonResizeSquare = new Button();
            buttonMoveSquare = new Button();
            buttonDrawSquare = new Button();
            pictureBoxForSquare = new PictureBox();
            drawRec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForSquare).BeginInit();
            SuspendLayout();
            // 
            // drawRec
            // 
            drawRec.Controls.Add(BackToMain);
            drawRec.Controls.Add(label7);
            drawRec.Controls.Add(label6);
            drawRec.Controls.Add(label5);
            drawRec.Controls.Add(label3);
            drawRec.Controls.Add(label2);
            drawRec.Controls.Add(label1);
            drawRec.Controls.Add(textBoxResizeSide);
            drawRec.Controls.Add(textBoxMoveY);
            drawRec.Controls.Add(textBoxMoveX);
            drawRec.Controls.Add(textBoxSide);
            drawRec.Controls.Add(textBoxSquareY);
            drawRec.Controls.Add(textBoxSquareX);
            drawRec.Controls.Add(buttonClear);
            drawRec.Controls.Add(buttonRemoveSquare);
            drawRec.Controls.Add(buttonResizeSquare);
            drawRec.Controls.Add(buttonMoveSquare);
            drawRec.Controls.Add(buttonDrawSquare);
            drawRec.Font = new Font("Microsoft JhengHei", 9F);
            drawRec.Location = new Point(8, 16);
            drawRec.Margin = new Padding(3, 4, 3, 4);
            drawRec.Name = "drawRec";
            drawRec.Padding = new Padding(3, 4, 3, 4);
            drawRec.Size = new Size(921, 761);
            drawRec.TabIndex = 3;
            drawRec.TabStop = false;
            drawRec.Text = "draw square!";
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(7, 715);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 22;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(18, 473);
            label7.Name = "label7";
            label7.Size = new Size(313, 19);
            label7.TabIndex = 19;
            label7.Text = "Введите новое значение стороны квадрата";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(522, 308);
            label6.Name = "label6";
            label6.Size = new Size(245, 19);
            label6.TabIndex = 18;
            label6.Text = "Введите новые координаты для у";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(522, 244);
            label5.Name = "label5";
            label5.Size = new Size(245, 19);
            label5.TabIndex = 17;
            label5.Text = "Введите новые координаты для х";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 236);
            label3.Name = "label3";
            label3.Size = new Size(267, 19);
            label3.TabIndex = 15;
            label3.Text = "Введите значение стороны квадрата";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 176);
            label2.Name = "label2";
            label2.Size = new Size(197, 19);
            label2.TabIndex = 14;
            label2.Text = "Введите координаты для у";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 125);
            label1.Name = "label1";
            label1.Size = new Size(197, 19);
            label1.TabIndex = 13;
            label1.Text = "Введите координаты для х";
            // 
            // textBoxResizeSide
            // 
            textBoxResizeSide.Location = new Point(337, 470);
            textBoxResizeSide.Margin = new Padding(3, 4, 3, 4);
            textBoxResizeSide.Name = "textBoxResizeSide";
            textBoxResizeSide.Size = new Size(114, 27);
            textBoxResizeSide.TabIndex = 11;
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(761, 308);
            textBoxMoveY.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(114, 27);
            textBoxMoveY.TabIndex = 10;
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(762, 244);
            textBoxMoveX.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(114, 27);
            textBoxMoveX.TabIndex = 9;
            // 
            // textBoxSide
            // 
            textBoxSide.Location = new Point(282, 232);
            textBoxSide.Margin = new Padding(3, 4, 3, 4);
            textBoxSide.Name = "textBoxSide";
            textBoxSide.Size = new Size(114, 27);
            textBoxSide.TabIndex = 7;
            // 
            // textBoxSquareY
            // 
            textBoxSquareY.Location = new Point(213, 176);
            textBoxSquareY.Margin = new Padding(3, 4, 3, 4);
            textBoxSquareY.Name = "textBoxSquareY";
            textBoxSquareY.Size = new Size(114, 27);
            textBoxSquareY.TabIndex = 6;
            // 
            // textBoxSquareX
            // 
            textBoxSquareX.Location = new Point(213, 121);
            textBoxSquareX.Margin = new Padding(3, 4, 3, 4);
            textBoxSquareX.Name = "textBoxSquareX";
            textBoxSquareX.Size = new Size(114, 27);
            textBoxSquareX.TabIndex = 5;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = Color.FromArgb(255, 128, 128);
            buttonClear.Location = new Point(775, 696);
            buttonClear.Margin = new Padding(3, 4, 3, 4);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(127, 55);
            buttonClear.TabIndex = 4;
            buttonClear.Text = "очистить все";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonRemoveSquare
            // 
            buttonRemoveSquare.BackColor = Color.FromArgb(192, 255, 192);
            buttonRemoveSquare.Location = new Point(669, 605);
            buttonRemoveSquare.Margin = new Padding(3, 4, 3, 4);
            buttonRemoveSquare.Name = "buttonRemoveSquare";
            buttonRemoveSquare.Size = new Size(233, 83);
            buttonRemoveSquare.TabIndex = 3;
            buttonRemoveSquare.Text = "удалить выбранный квадрат";
            buttonRemoveSquare.UseVisualStyleBackColor = false;
            buttonRemoveSquare.Click += buttonRemoveSquare_Click;
            // 
            // buttonResizeSquare
            // 
            buttonResizeSquare.BackColor = Color.FromArgb(224, 224, 224);
            buttonResizeSquare.Location = new Point(18, 383);
            buttonResizeSquare.Margin = new Padding(3, 4, 3, 4);
            buttonResizeSquare.Name = "buttonResizeSquare";
            buttonResizeSquare.Size = new Size(198, 65);
            buttonResizeSquare.TabIndex = 2;
            buttonResizeSquare.Text = "Изменить размер фигуры";
            buttonResizeSquare.UseVisualStyleBackColor = false;
            buttonResizeSquare.Click += buttonResizeSquare_Click;
            // 
            // buttonMoveSquare
            // 
            buttonMoveSquare.BackColor = SystemColors.ActiveCaption;
            buttonMoveSquare.Location = new Point(522, 156);
            buttonMoveSquare.Margin = new Padding(3, 4, 3, 4);
            buttonMoveSquare.Name = "buttonMoveSquare";
            buttonMoveSquare.Size = new Size(245, 53);
            buttonMoveSquare.TabIndex = 1;
            buttonMoveSquare.Text = "Сдвинуть фигуру";
            buttonMoveSquare.UseVisualStyleBackColor = false;
            buttonMoveSquare.Click += buttonMoveSquare_Click;
            // 
            // buttonDrawSquare
            // 
            buttonDrawSquare.BackColor = Color.FromArgb(255, 224, 192);
            buttonDrawSquare.Location = new Point(18, 49);
            buttonDrawSquare.Margin = new Padding(3, 4, 3, 4);
            buttonDrawSquare.Name = "buttonDrawSquare";
            buttonDrawSquare.Size = new Size(241, 53);
            buttonDrawSquare.TabIndex = 0;
            buttonDrawSquare.Text = "Нарисовать фигуру";
            buttonDrawSquare.UseVisualStyleBackColor = false;
            buttonDrawSquare.Click += buttonDrawSquare_Click;
            // 
            // pictureBoxForSquare
            // 
            pictureBoxForSquare.BackColor = Color.FromArgb(224, 224, 224);
            pictureBoxForSquare.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxForSquare.Location = new Point(969, 16);
            pictureBoxForSquare.Margin = new Padding(3, 4, 3, 4);
            pictureBoxForSquare.Name = "pictureBoxForSquare";
            pictureBoxForSquare.Size = new Size(556, 761);
            pictureBoxForSquare.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxForSquare.TabIndex = 2;
            pictureBoxForSquare.TabStop = false;
            pictureBoxForSquare.MouseClick += PictureBox1_MouseClick;
            // 
            // Square
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1563, 793);
            Controls.Add(drawRec);
            Controls.Add(pictureBoxForSquare);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Square";
            Text = "Square";
            Load += Square_Load;
            drawRec.ResumeLayout(false);
            drawRec.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForSquare).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox drawRec;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBoxResizeH;
        private TextBox textBoxResizeSide;
        private TextBox textBoxMoveY;
        private TextBox textBoxMoveX;
        private TextBox textBoxH;
        private TextBox textBoxSide;
        private TextBox textBoxSquareY;
        private TextBox textBoxSquareX;
        private Button buttonClear;
        private Button buttonRemoveSquare;
        private Button buttonResizeSquare;
        private Button buttonMoveSquare;
        private Button buttonDrawSquare;
        private PictureBox pictureBoxForSquare;
        private Button BackToMain;
    }
}