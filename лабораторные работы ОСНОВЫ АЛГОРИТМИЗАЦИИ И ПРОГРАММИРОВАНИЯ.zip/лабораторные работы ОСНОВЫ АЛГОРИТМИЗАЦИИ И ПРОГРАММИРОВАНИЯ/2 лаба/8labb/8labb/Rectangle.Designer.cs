﻿namespace _8labb
{
    partial class Rectangle
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxForRectangle = new PictureBox();
            drawRec = new GroupBox();
            BackToMain = new Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBoxResizeH = new TextBox();
            textBoxResizeW = new TextBox();
            textBoxMoveY = new TextBox();
            textBoxMoveX = new TextBox();
            textBoxH = new TextBox();
            textBoxW = new TextBox();
            textBoxRectY = new TextBox();
            textBoxRectX = new TextBox();
            buttonClear = new Button();
            buttonRemoveRectangle = new Button();
            buttonResizeRectangle = new Button();
            buttonMoveRectangle = new Button();
            buttonDrawRectangle = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForRectangle).BeginInit();
            drawRec.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBoxForRectangle
            // 
            pictureBoxForRectangle.BackColor = Color.FromArgb(224, 224, 224);
            pictureBoxForRectangle.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxForRectangle.Location = new Point(779, 16);
            pictureBoxForRectangle.Margin = new Padding(3, 4, 3, 4);
            pictureBoxForRectangle.Name = "pictureBoxForRectangle";
            pictureBoxForRectangle.Size = new Size(556, 761);
            pictureBoxForRectangle.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxForRectangle.TabIndex = 0;
            pictureBoxForRectangle.TabStop = false;
            pictureBoxForRectangle.MouseClick += PictureBox1_MouseClick;
            // 
            // drawRec
            // 
            drawRec.Controls.Add(BackToMain);
            drawRec.Controls.Add(label8);
            drawRec.Controls.Add(label7);
            drawRec.Controls.Add(label6);
            drawRec.Controls.Add(label5);
            drawRec.Controls.Add(label4);
            drawRec.Controls.Add(label3);
            drawRec.Controls.Add(label2);
            drawRec.Controls.Add(label1);
            drawRec.Controls.Add(textBoxResizeH);
            drawRec.Controls.Add(textBoxResizeW);
            drawRec.Controls.Add(textBoxMoveY);
            drawRec.Controls.Add(textBoxMoveX);
            drawRec.Controls.Add(textBoxH);
            drawRec.Controls.Add(textBoxW);
            drawRec.Controls.Add(textBoxRectY);
            drawRec.Controls.Add(textBoxRectX);
            drawRec.Controls.Add(buttonClear);
            drawRec.Controls.Add(buttonRemoveRectangle);
            drawRec.Controls.Add(buttonResizeRectangle);
            drawRec.Controls.Add(buttonMoveRectangle);
            drawRec.Controls.Add(buttonDrawRectangle);
            drawRec.Font = new Font("Microsoft JhengHei", 9F);
            drawRec.Location = new Point(14, 16);
            drawRec.Margin = new Padding(3, 4, 3, 4);
            drawRec.Name = "drawRec";
            drawRec.Padding = new Padding(3, 4, 3, 4);
            drawRec.Size = new Size(759, 761);
            drawRec.TabIndex = 1;
            drawRec.TabStop = false;
            drawRec.Text = "draw rectangle!";
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(7, 715);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 21;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(7, 520);
            label8.Name = "label8";
            label8.Size = new Size(239, 19);
            label8.TabIndex = 20;
            label8.Text = "Введите новое значение высоты";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(7, 455);
            label7.Name = "label7";
            label7.Size = new Size(239, 19);
            label7.TabIndex = 19;
            label7.Text = "Введите новое значение ширины";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(369, 163);
            label6.Name = "label6";
            label6.Size = new Size(245, 19);
            label6.TabIndex = 18;
            label6.Text = "Введите новые координаты для у";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(369, 121);
            label5.Name = "label5";
            label5.Size = new Size(245, 19);
            label5.TabIndex = 17;
            label5.Text = "Введите новые координаты для х";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 277);
            label4.Name = "label4";
            label4.Size = new Size(193, 19);
            label4.TabIndex = 16;
            label4.Text = "Введите значение высоты";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 216);
            label3.Name = "label3";
            label3.Size = new Size(193, 19);
            label3.TabIndex = 15;
            label3.Text = "Введите значение ширины";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(7, 156);
            label2.Name = "label2";
            label2.Size = new Size(197, 19);
            label2.TabIndex = 14;
            label2.Text = "Введите координаты для у";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(7, 105);
            label1.Name = "label1";
            label1.Size = new Size(197, 19);
            label1.TabIndex = 13;
            label1.Text = "Введите координаты для х";
            // 
            // textBoxResizeH
            // 
            textBoxResizeH.Location = new Point(243, 516);
            textBoxResizeH.Margin = new Padding(3, 4, 3, 4);
            textBoxResizeH.Name = "textBoxResizeH";
            textBoxResizeH.Size = new Size(114, 27);
            textBoxResizeH.TabIndex = 12;
            // 
            // textBoxResizeW
            // 
            textBoxResizeW.Location = new Point(243, 451);
            textBoxResizeW.Margin = new Padding(3, 4, 3, 4);
            textBoxResizeW.Name = "textBoxResizeW";
            textBoxResizeW.Size = new Size(114, 27);
            textBoxResizeW.TabIndex = 11;
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(626, 156);
            textBoxMoveY.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(114, 27);
            textBoxMoveY.TabIndex = 10;
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(626, 118);
            textBoxMoveX.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(114, 27);
            textBoxMoveX.TabIndex = 9;
            // 
            // textBoxH
            // 
            textBoxH.Location = new Point(206, 274);
            textBoxH.Margin = new Padding(3, 4, 3, 4);
            textBoxH.Name = "textBoxH";
            textBoxH.Size = new Size(114, 27);
            textBoxH.TabIndex = 8;
            // 
            // textBoxW
            // 
            textBoxW.Location = new Point(206, 216);
            textBoxW.Margin = new Padding(3, 4, 3, 4);
            textBoxW.Name = "textBoxW";
            textBoxW.Size = new Size(114, 27);
            textBoxW.TabIndex = 7;
            // 
            // textBoxRectY
            // 
            textBoxRectY.Location = new Point(210, 155);
            textBoxRectY.Margin = new Padding(3, 4, 3, 4);
            textBoxRectY.Name = "textBoxRectY";
            textBoxRectY.Size = new Size(114, 27);
            textBoxRectY.TabIndex = 6;
            // 
            // textBoxRectX
            // 
            textBoxRectX.Location = new Point(210, 102);
            textBoxRectX.Margin = new Padding(3, 4, 3, 4);
            textBoxRectX.Name = "textBoxRectX";
            textBoxRectX.Size = new Size(114, 27);
            textBoxRectX.TabIndex = 5;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = Color.FromArgb(255, 128, 128);
            buttonClear.Location = new Point(589, 687);
            buttonClear.Margin = new Padding(3, 4, 3, 4);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(151, 65);
            buttonClear.TabIndex = 4;
            buttonClear.Text = "очистить все";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonRemoveRectangle
            // 
            buttonRemoveRectangle.BackColor = Color.FromArgb(192, 255, 192);
            buttonRemoveRectangle.Location = new Point(496, 631);
            buttonRemoveRectangle.Margin = new Padding(3, 4, 3, 4);
            buttonRemoveRectangle.Name = "buttonRemoveRectangle";
            buttonRemoveRectangle.Size = new Size(257, 48);
            buttonRemoveRectangle.TabIndex = 3;
            buttonRemoveRectangle.Text = "удалить выбранный прямоугольник";
            buttonRemoveRectangle.UseVisualStyleBackColor = false;
            buttonRemoveRectangle.Click += buttonRemoveRectangle_Click;
            // 
            // buttonResizeRectangle
            // 
            buttonResizeRectangle.BackColor = Color.FromArgb(224, 224, 224);
            buttonResizeRectangle.Location = new Point(23, 352);
            buttonResizeRectangle.Margin = new Padding(3, 4, 3, 4);
            buttonResizeRectangle.Name = "buttonResizeRectangle";
            buttonResizeRectangle.Size = new Size(198, 65);
            buttonResizeRectangle.TabIndex = 2;
            buttonResizeRectangle.Text = "Изменить размер фигуры";
            buttonResizeRectangle.UseVisualStyleBackColor = false;
            buttonResizeRectangle.Click += buttonResizeRectangle_Click;
            // 
            // buttonMoveRectangle
            // 
            buttonMoveRectangle.BackColor = SystemColors.ActiveCaption;
            buttonMoveRectangle.Location = new Point(462, 29);
            buttonMoveRectangle.Margin = new Padding(3, 4, 3, 4);
            buttonMoveRectangle.Name = "buttonMoveRectangle";
            buttonMoveRectangle.Size = new Size(245, 53);
            buttonMoveRectangle.TabIndex = 1;
            buttonMoveRectangle.Text = "Сдвинуть фигуру";
            buttonMoveRectangle.UseVisualStyleBackColor = false;
            buttonMoveRectangle.Click += buttonMoveRectangle_Click;
            // 
            // buttonDrawRectangle
            // 
            buttonDrawRectangle.BackColor = Color.FromArgb(255, 224, 192);
            buttonDrawRectangle.Location = new Point(23, 29);
            buttonDrawRectangle.Margin = new Padding(3, 4, 3, 4);
            buttonDrawRectangle.Name = "buttonDrawRectangle";
            buttonDrawRectangle.Size = new Size(241, 53);
            buttonDrawRectangle.TabIndex = 0;
            buttonDrawRectangle.Text = "Нарисовать фигуру";
            buttonDrawRectangle.UseVisualStyleBackColor = false;
            buttonDrawRectangle.Click += buttonDrawRectangle_Click;
            // 
            // Rectangle
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1347, 793);
            Controls.Add(drawRec);
            Controls.Add(pictureBoxForRectangle);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Rectangle";
            Text = "Rectangle";
            Load += Rectangle_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxForRectangle).EndInit();
            drawRec.ResumeLayout(false);
            drawRec.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBoxForRectangle;
        private GroupBox drawRec;
        private Button buttonClear;
        private Button buttonRemoveRectangle;
        private Button buttonResizeRectangle;
        private Button buttonMoveRectangle;
        private Button buttonDrawRectangle;
        private TextBox textBoxResizeH;
        private TextBox textBoxResizeW;
        private TextBox textBoxMoveY;
        private TextBox textBoxMoveX;
        private TextBox textBoxH;
        private TextBox textBoxW;
        private TextBox textBoxRectY;
        private TextBox textBoxRectX;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Button BackToMain;
    }
}
