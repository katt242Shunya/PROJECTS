﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLib;

namespace _8labb
{
    public partial class Circle : Form
    {
        private CircleFigure currentCircle = null;
        private int pictureBoxWidth;
        private int pictureBoxHeight;

        public Circle()
        {
            InitializeComponent();
            pictureBoxForCircle.MouseClick += PictureBox1_MouseClick;
        }

        private void Circle_Load(object sender, EventArgs e)
        {
            pictureBoxWidth = pictureBoxForCircle.Width;
            pictureBoxHeight = pictureBoxForCircle.Height;
            Init.Initialize(pictureBoxForCircle, pictureBoxWidth, pictureBoxHeight);
            Init.ClearBitmap();
        }

        private void RedrawAll()
        {
            Init.ClearBitmap();
            using (Graphics g = Graphics.FromImage(Init.bitmap))
            {
                ShapeContainer.DrawAll(g);
            }
            Init.UpdatePictureBox();
        }

        private void buttonDrawCircle_Click(object sender, EventArgs e)
        {
            int x, y, radius;

            if (textBoxCircleX.Text.Length > 3 || textBoxCircleY.Text.Length > 3 || textBoxRadius.Text.Length > 3)
            {
                MessageBox.Show("Введите не более трех символов");
                return;
            }
            try
            {
                x = int.Parse(textBoxCircleX.Text);
                y = int.Parse(textBoxCircleY.Text);
                radius = int.Parse(textBoxRadius.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка ввода: введите число");
                return;
            }

            if (x < 0 || y < 0 || radius < 0)
            {
                MessageBox.Show("Значение не может быть отрицательным");
                return;
            }

            if (x + radius * 2 > Init.pictureBoxWidth || y + radius * 2 > Init.pictureBoxHeight)
            {
                MessageBox.Show("Круг выходит за границы");
                return;
            }

            CircleFigure circle = new CircleFigure(x, y, radius);
            ShapeContainer.AddFigure(circle);
            RedrawAll();

            currentCircle = circle;

            textBoxCircleX.Text = "";
            textBoxCircleY.Text = "";
            textBoxRadius.Text = "";
        }


        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (var figure in ShapeContainer.figureList)
            {
                figure.IsSelected = false;
            }

            for (int i = ShapeContainer.figureList.Count - 1; i >= 0; i--)
            {
                FigureClass figure = ShapeContainer.figureList[i];
                if (figure is CircleFigure circle && circle.Contains(e.X, e.Y))
                {
                    currentCircle = circle;
                    currentCircle.IsSelected = true;
                    RedrawAll();
                    return;
                }
            }
            currentCircle = null;
            RedrawAll();
        }

        private void buttonMoveCircle_Click(object sender, EventArgs e)
        {
            int moveX, moveY;

            if (currentCircle == null)
            {
                MessageBox.Show("Сначала выберите эллипс");
                return;
            }
            try
            {
                moveX = int.Parse(textBoxMoveX.Text);
                moveY = int.Parse(textBoxMoveY.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный ввод чисел");
                return;
            }
            int newX = currentCircle.x + moveX;
            int newY = currentCircle.y + moveY;

            int ellipseLeft = newX;
            int ellipseTop = newY;
            int ellipseRight = newX + currentCircle.RadiusWidth * 2;
            int ellipseBottom = newY + currentCircle.RadiusHeight * 2;

            if (ellipseLeft < 0)
            {
                newX = 0;
            }
            else if (ellipseRight > Init.pictureBoxWidth)
            {
                newX = Init.pictureBoxWidth - currentCircle.RadiusWidth * 2;
            }

            if (ellipseTop < 0)
            {
                newY = 0;
            }
            else if (ellipseBottom > Init.pictureBoxHeight)
            {
                newY = Init.pictureBoxHeight - currentCircle.RadiusHeight * 2;
            }
            ellipseLeft = newX;
            ellipseTop = newY;
            ellipseRight = newX + currentCircle.RadiusWidth * 2;
            ellipseBottom = newY + currentCircle.RadiusHeight * 2;

            if ((moveX < 0 && ellipseLeft == 0) || (moveX > 0 && ellipseRight == Init.pictureBoxWidth) || (moveY < 0 && ellipseTop == 0) || (moveY > 0 && ellipseBottom == Init.pictureBoxHeight))
            {
                MessageBox.Show("Перемещение больше недоступно эллипс достиг границы");
                return;
            }

            currentCircle.MoveTo(newX, newY);
            currentCircle.x = newX;
            currentCircle.y = newY;

            RedrawAll();
        }

        private void buttonResizeCircle_Click(object sender, EventArgs e)
        {
            int deltaRadius;

            if (currentCircle == null)
            {
                MessageBox.Show("Сначала выберите круг");
                return;
            }

            try
            {
                deltaRadius = int.Parse(textBoxResizeRadius.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный ввод числа");
                return;
            }
            int newRadius = currentCircle.Radius + deltaRadius;

            if (newRadius < 0)
            {
                MessageBox.Show("Радиус не может быть отрицательным");
                return;
            }
            int maxRadiusX = Math.Min(currentCircle.x, Init.pictureBoxWidth - currentCircle.x);
            int maxRadiusY = Math.Min(currentCircle.y, Init.pictureBoxHeight - currentCircle.y);

            if (newRadius > maxRadiusX || newRadius > maxRadiusY)
            {
                newRadius = Math.Min(maxRadiusX, maxRadiusY);
                MessageBox.Show("Радиус уменьшен до максимально возможного значения");
            }

            currentCircle.Resize(newRadius, newRadius);

            RedrawAll();
        }

        private void buttonRemoveCircle_Click(object sender, EventArgs e)
        {
            if (currentCircle == null)
            {
                MessageBox.Show("Сначала выберите круг");
                return;
            }

            ShapeContainer.RemoveFigure(currentCircle);
            currentCircle = null;
            RedrawAll();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            currentCircle = null;
            Init.ClearBitmap();
        }

        private void BackToMain_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();

            Main main = new Main();
            main.Show();
            Hide();
        }
    }
}