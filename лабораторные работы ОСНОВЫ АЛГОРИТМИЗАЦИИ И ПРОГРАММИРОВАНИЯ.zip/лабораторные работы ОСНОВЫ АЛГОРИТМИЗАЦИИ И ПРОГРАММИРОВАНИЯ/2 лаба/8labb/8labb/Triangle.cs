﻿using MyLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8labb
{
    public partial class Triangle : Form
    {
        private PolygonFigure currentTriangle = null;
        private PointF[] pointFs = new PointF[3];
        private int i = 0;
        private bool flag = false;

        public Triangle()
        {
            InitializeComponent();
        }

        private void Triangle_Load(object sender, EventArgs e)
        {
            Init.Initialize(pictureBoxForTriangle, pictureBoxForTriangle.Width, pictureBoxForTriangle.Height);
            buttonDrawTriangle.Enabled = false;
            textBoxCoordX.Enabled = false;
            textBoxCoordY.Enabled = false;
            buttonCreatePoint.Enabled = true;

            textBoxMoveX.Enabled = false; 
            textBoxMoveY.Enabled = false;
            buttonMoveTriangle.Enabled = false; 
        }

        private void RedrawAll()
        {
            Init.ClearBitmap();
            using (Graphics g = Graphics.FromImage(Init.bitmap))
            {
                ShapeContainer.DrawAll(g);
            }
            Init.UpdatePictureBox();
        }

        private void ButtonCreatePoint_Click(object sender, EventArgs e)
        {
            if (!flag)
            {
                flag = true;
                textBoxCoordX.Enabled = true;
                textBoxCoordY.Enabled = true;
            }

            if (i < 2)
            {
                if (!float.TryParse(textBoxCoordX.Text, out float x) ||
                    !float.TryParse(textBoxCoordY.Text, out float y))
                {
                    MessageBox.Show("Введите корректные координаты.");
                    return;
                }
                x = Math.Max(0, Math.Min(x, pictureBoxForTriangle.Width));
                y = Math.Max(0, Math.Min(y, pictureBoxForTriangle.Height));

                pointFs[i].X = x;
                pointFs[i].Y = y;
                i++;
                label1.Text = $"Введите координаты {i + 1}-й точки: ";
                textBoxCoordX.Text = "";
                textBoxCoordY.Text = "";
                buttonDrawTriangle.Enabled = false;
            }
            else
            {
                if (!float.TryParse(textBoxCoordX.Text, out float x) ||
                    !float.TryParse(textBoxCoordY.Text, out float y))
                {
                    MessageBox.Show("Введите корректные координаты.");
                    return;
                }

                x = Math.Max(0, Math.Min(x, pictureBoxForTriangle.Width));
                y = Math.Max(0, Math.Min(y, pictureBoxForTriangle.Height));

                pointFs[i].X = x;
                pointFs[i].Y = y;
                buttonCreatePoint.Enabled = false;
                buttonDrawTriangle.Enabled = true;
                flag = false;
            }
        }

        private void ButtonDrawTriangle_Click(object sender, EventArgs e)
        {
            TriangleFigure triangle = new TriangleFigure(pointFs[0], pointFs[1], pointFs[2]);
            ShapeContainer.AddFigure(triangle);
            RedrawAll();

            buttonCreatePoint.Enabled = true;
            buttonDrawTriangle.Enabled = false;
            textBoxCoordX.Enabled = false;
            textBoxCoordY.Enabled = false;
            textBoxCoordX.Clear();
            textBoxCoordY.Clear();
            label1.Text = "";
            i = 0;
            flag = false;

            textBoxMoveX.Enabled = true; 
            textBoxMoveY.Enabled = true;
            buttonMoveTriangle.Enabled = true; 
        }
        private void ButtonMoveTriangle_Click(object sender, EventArgs e)
        {
            TriangleFigure selectedTriangle = null;

            foreach (var figure in ShapeContainer.figureList)
            {
                if (figure is TriangleFigure t && t.IsSelected)
                {
                    selectedTriangle = t;
                    break;
                }
            }

            if (selectedTriangle == null)
            {
                MessageBox.Show("Сначала выберите треугольник для перемещения.");
                return;
            }

            if (!int.TryParse(textBoxMoveX.Text, out int moveX) ||
                !int.TryParse(textBoxMoveY.Text, out int moveY))
            {
                MessageBox.Show("Введите корректные *целые* значения для перемещения.");
                return;
            }

            PointF[] points = selectedTriangle.points;
            int minX = (int)points[0].X;
            int minY = (int)points[0].Y;
            int maxX = (int)points[0].X;
            int maxY = (int)points[0].Y;

            for (int i = 1; i < 3; i++)
            {
                minX = Math.Min(minX, (int)points[i].X);
                minY = Math.Min(minY, (int)points[i].Y);
                maxX = Math.Max(maxX, (int)points[i].X);
                maxY = Math.Max(maxY, (int)points[i].Y);
            }

            int width = maxX - minX;
            int height = maxY - minY;

            int deltaX = 0;
            int deltaY = 0;

            if (minX + moveX < 0)
            {
                deltaX = -minX; 
            }
            else if (maxX + moveX > pictureBoxForTriangle.Width)
            {
                deltaX = pictureBoxForTriangle.Width - maxX; 
            }
            else
            {
                deltaX = moveX; 
            }
            if (minY + moveY < 0)
            {
                deltaY = -minY; 
            }
            else if (maxY + moveY > pictureBoxForTriangle.Height)
            {
                deltaY = pictureBoxForTriangle.Height - maxY; 
            }
            else
            {
                deltaY = moveY; 
            }

            for (int i = 0; i < 3; i++)
            {
                points[i] = new PointF(points[i].X + deltaX, points[i].Y + deltaY);
            }

           
            selectedTriangle.x = (int)points[0].X;
            selectedTriangle.y = (int)points[0].Y;

            RedrawAll();
        }

        private void ButtonRemoveTriangle_Click(object sender, EventArgs e)
        {
            TriangleFigure selectedTriangle = null;

            
            foreach (var figure in ShapeContainer.figureList)
            {
                if (figure is TriangleFigure t && t.IsSelected)
                {
                    selectedTriangle = t;
                    break;
                }
            }

            if (selectedTriangle == null)
            {
                MessageBox.Show("сначала выберите треугольник");
                return;
            }

            ShapeContainer.RemoveFigure(selectedTriangle);
            selectedTriangle = null;
            RedrawAll();
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();
        }

        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (var figure in ShapeContainer.figureList)
            {
                figure.IsSelected = false;
            }

            for (int j = ShapeContainer.figureList.Count - 1; j >= 0; j--)
            {
                FigureClass figure = ShapeContainer.figureList[j];
                if (figure is TriangleFigure triangle && triangle.Contains(e.X, e.Y))
                {
                    currentTriangle = triangle;
                    currentTriangle.IsSelected = true;
                    RedrawAll();
                    return;
                }
            }
            currentTriangle = null;
            RedrawAll();
        }

        private void BackToMain_Click(object sender, EventArgs e)
        {
           
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();

            Main main = new Main();
            main.Show();
            Hide();
        }
    
    }
}
