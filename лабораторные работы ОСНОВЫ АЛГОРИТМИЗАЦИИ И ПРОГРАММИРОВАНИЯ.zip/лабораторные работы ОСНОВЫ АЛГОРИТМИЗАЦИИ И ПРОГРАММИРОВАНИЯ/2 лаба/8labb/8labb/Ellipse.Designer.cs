﻿namespace _8labb
{
    partial class Ellipse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            drawRec = new GroupBox();
            BackToMain = new Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBoxResizeRadiusHeight = new TextBox();
            textBoxResizeRadiusWidth = new TextBox();
            textBoxMoveY = new TextBox();
            textBoxMoveX = new TextBox();
            textBoxRadiusHeight = new TextBox();
            textBoxRadiusWidth = new TextBox();
            textBoxEllipseY = new TextBox();
            textBoxEllipseX = new TextBox();
            buttonClear = new Button();
            buttonRemoveEllipse = new Button();
            buttonResizeEllipse = new Button();
            buttonMoveEllipse = new Button();
            buttonDrawEllipse = new Button();
            pictureBoxForEllipse = new PictureBox();
            drawRec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForEllipse).BeginInit();
            SuspendLayout();
            // 
            // drawRec
            // 
            drawRec.Controls.Add(BackToMain);
            drawRec.Controls.Add(label8);
            drawRec.Controls.Add(label7);
            drawRec.Controls.Add(label6);
            drawRec.Controls.Add(label5);
            drawRec.Controls.Add(label4);
            drawRec.Controls.Add(label3);
            drawRec.Controls.Add(label2);
            drawRec.Controls.Add(label1);
            drawRec.Controls.Add(textBoxResizeRadiusHeight);
            drawRec.Controls.Add(textBoxResizeRadiusWidth);
            drawRec.Controls.Add(textBoxMoveY);
            drawRec.Controls.Add(textBoxMoveX);
            drawRec.Controls.Add(textBoxRadiusHeight);
            drawRec.Controls.Add(textBoxRadiusWidth);
            drawRec.Controls.Add(textBoxEllipseY);
            drawRec.Controls.Add(textBoxEllipseX);
            drawRec.Controls.Add(buttonClear);
            drawRec.Controls.Add(buttonRemoveEllipse);
            drawRec.Controls.Add(buttonResizeEllipse);
            drawRec.Controls.Add(buttonMoveEllipse);
            drawRec.Controls.Add(buttonDrawEllipse);
            drawRec.Font = new Font("Microsoft JhengHei", 9F);
            drawRec.Location = new Point(-1, 16);
            drawRec.Margin = new Padding(3, 4, 3, 4);
            drawRec.Name = "drawRec";
            drawRec.Padding = new Padding(3, 4, 3, 4);
            drawRec.Size = new Size(840, 761);
            drawRec.TabIndex = 3;
            drawRec.TabStop = false;
            drawRec.Text = "draw ellipse!";
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(7, 715);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 21;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(29, 556);
            label8.Name = "label8";
            label8.Size = new Size(317, 19);
            label8.TabIndex = 20;
            label8.Text = "Введите новое значение радиуса по высоте";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(29, 491);
            label7.Name = "label7";
            label7.Size = new Size(317, 19);
            label7.TabIndex = 19;
            label7.Text = "Введите новое значение радиуса по ширине";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(465, 163);
            label6.Name = "label6";
            label6.Size = new Size(245, 19);
            label6.TabIndex = 18;
            label6.Text = "Введите новые координаты для у";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(465, 121);
            label5.Name = "label5";
            label5.Size = new Size(245, 19);
            label5.TabIndex = 17;
            label5.Text = "Введите новые координаты для х";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(25, 277);
            label4.Name = "label4";
            label4.Size = new Size(271, 19);
            label4.TabIndex = 16;
            label4.Text = "Введите значение радиуса по высоте";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 216);
            label3.Name = "label3";
            label3.Size = new Size(271, 19);
            label3.TabIndex = 15;
            label3.Text = "Введите значение радиуса по ширине";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 156);
            label2.Name = "label2";
            label2.Size = new Size(197, 19);
            label2.TabIndex = 14;
            label2.Text = "Введите координаты для у";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 105);
            label1.Name = "label1";
            label1.Size = new Size(197, 19);
            label1.TabIndex = 13;
            label1.Text = "Введите координаты для х";
            // 
            // textBoxResizeRadiusHeight
            // 
            textBoxResizeRadiusHeight.Location = new Point(352, 553);
            textBoxResizeRadiusHeight.Margin = new Padding(3, 4, 3, 4);
            textBoxResizeRadiusHeight.Name = "textBoxResizeRadiusHeight";
            textBoxResizeRadiusHeight.Size = new Size(114, 27);
            textBoxResizeRadiusHeight.TabIndex = 12;
            // 
            // textBoxResizeRadiusWidth
            // 
            textBoxResizeRadiusWidth.Location = new Point(352, 488);
            textBoxResizeRadiusWidth.Margin = new Padding(3, 4, 3, 4);
            textBoxResizeRadiusWidth.Name = "textBoxResizeRadiusWidth";
            textBoxResizeRadiusWidth.Size = new Size(114, 27);
            textBoxResizeRadiusWidth.TabIndex = 11;
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(716, 160);
            textBoxMoveY.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(114, 27);
            textBoxMoveY.TabIndex = 10;
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(718, 118);
            textBoxMoveX.Margin = new Padding(3, 4, 3, 4);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(114, 27);
            textBoxMoveX.TabIndex = 9;
            // 
            // textBoxRadiusHeight
            // 
            textBoxRadiusHeight.Location = new Point(302, 274);
            textBoxRadiusHeight.Margin = new Padding(3, 4, 3, 4);
            textBoxRadiusHeight.Name = "textBoxRadiusHeight";
            textBoxRadiusHeight.Size = new Size(114, 27);
            textBoxRadiusHeight.TabIndex = 8;
            // 
            // textBoxRadiusWidth
            // 
            textBoxRadiusWidth.Location = new Point(300, 213);
            textBoxRadiusWidth.Margin = new Padding(3, 4, 3, 4);
            textBoxRadiusWidth.Name = "textBoxRadiusWidth";
            textBoxRadiusWidth.Size = new Size(114, 27);
            textBoxRadiusWidth.TabIndex = 7;
            // 
            // textBoxEllipseY
            // 
            textBoxEllipseY.Location = new Point(226, 153);
            textBoxEllipseY.Margin = new Padding(3, 4, 3, 4);
            textBoxEllipseY.Name = "textBoxEllipseY";
            textBoxEllipseY.Size = new Size(114, 27);
            textBoxEllipseY.TabIndex = 6;
            // 
            // textBoxEllipseX
            // 
            textBoxEllipseX.Location = new Point(226, 102);
            textBoxEllipseX.Margin = new Padding(3, 4, 3, 4);
            textBoxEllipseX.Name = "textBoxEllipseX";
            textBoxEllipseX.Size = new Size(114, 27);
            textBoxEllipseX.TabIndex = 5;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = Color.FromArgb(255, 128, 128);
            buttonClear.Location = new Point(681, 683);
            buttonClear.Margin = new Padding(3, 4, 3, 4);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(151, 65);
            buttonClear.TabIndex = 4;
            buttonClear.Text = "очистить все";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonRemoveEllipse
            // 
            buttonRemoveEllipse.BackColor = Color.FromArgb(192, 255, 192);
            buttonRemoveEllipse.Location = new Point(570, 627);
            buttonRemoveEllipse.Margin = new Padding(3, 4, 3, 4);
            buttonRemoveEllipse.Name = "buttonRemoveEllipse";
            buttonRemoveEllipse.Size = new Size(257, 48);
            buttonRemoveEllipse.TabIndex = 3;
            buttonRemoveEllipse.Text = "удалить выбранный эллипс";
            buttonRemoveEllipse.UseVisualStyleBackColor = false;
            buttonRemoveEllipse.Click += buttonRemoveEllipse_Click;
            buttonRemoveEllipse.MouseClick += PictureBox1_MouseClick;
            // 
            // buttonResizeEllipse
            // 
            buttonResizeEllipse.BackColor = Color.FromArgb(224, 224, 224);
            buttonResizeEllipse.Location = new Point(23, 400);
            buttonResizeEllipse.Margin = new Padding(3, 4, 3, 4);
            buttonResizeEllipse.Name = "buttonResizeEllipse";
            buttonResizeEllipse.Size = new Size(198, 65);
            buttonResizeEllipse.TabIndex = 2;
            buttonResizeEllipse.Text = "Изменить размер фигуры";
            buttonResizeEllipse.UseVisualStyleBackColor = false;
            buttonResizeEllipse.Click += buttonResizeEllipse_Click;
            // 
            // buttonMoveEllipse
            // 
            buttonMoveEllipse.BackColor = SystemColors.ActiveCaption;
            buttonMoveEllipse.Location = new Point(570, 29);
            buttonMoveEllipse.Margin = new Padding(3, 4, 3, 4);
            buttonMoveEllipse.Name = "buttonMoveEllipse";
            buttonMoveEllipse.Size = new Size(245, 53);
            buttonMoveEllipse.TabIndex = 1;
            buttonMoveEllipse.Text = "Сдвинуть фигуру";
            buttonMoveEllipse.UseVisualStyleBackColor = false;
            buttonMoveEllipse.Click += buttonMoveEllipse_Click;
            // 
            // buttonDrawEllipse
            // 
            buttonDrawEllipse.BackColor = Color.FromArgb(255, 224, 192);
            buttonDrawEllipse.Location = new Point(23, 29);
            buttonDrawEllipse.Margin = new Padding(3, 4, 3, 4);
            buttonDrawEllipse.Name = "buttonDrawEllipse";
            buttonDrawEllipse.Size = new Size(241, 53);
            buttonDrawEllipse.TabIndex = 0;
            buttonDrawEllipse.Text = "Нарисовать фигуру";
            buttonDrawEllipse.UseVisualStyleBackColor = false;
            buttonDrawEllipse.Click += buttonDrawEllipse_Click;
            // 
            // pictureBoxForEllipse
            // 
            pictureBoxForEllipse.BackColor = Color.FromArgb(224, 224, 224);
            pictureBoxForEllipse.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxForEllipse.Location = new Point(883, 16);
            pictureBoxForEllipse.Margin = new Padding(3, 4, 3, 4);
            pictureBoxForEllipse.Name = "pictureBoxForEllipse";
            pictureBoxForEllipse.Size = new Size(556, 761);
            pictureBoxForEllipse.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxForEllipse.TabIndex = 2;
            pictureBoxForEllipse.TabStop = false;
            // 
            // Ellipse
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1454, 793);
            Controls.Add(drawRec);
            Controls.Add(pictureBoxForEllipse);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Ellipse";
            Text = "Ellipse";
            Load += Ellipse_Load;
            drawRec.ResumeLayout(false);
            drawRec.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForEllipse).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox drawRec;
        private Button BackToMain;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBoxResizeRadiusHeight;
        private TextBox textBoxResizeRadiusWidth;
        private TextBox textBoxMoveY;
        private TextBox textBoxMoveX;
        private TextBox textBoxRadiusHeight;
        private TextBox textBoxRadiusWidth;
        private TextBox textBoxEllipseY;
        private TextBox textBoxEllipseX;
        private Button buttonClear;
        private Button buttonRemoveEllipse;
        private Button buttonResizeEllipse;
        private Button buttonMoveEllipse;
        private Button buttonDrawEllipse;
        private PictureBox pictureBoxForEllipse;
    }
}