﻿namespace _8labb
{
    partial class ChristmasTree
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxForChristmasTree = new PictureBox();
            groupBoxTree = new GroupBox();
            labelCircleRadius = new Label();
            labelMoveY = new Label();
            labelMoveX = new Label();
            labelTriangleHeight = new Label();
            labelriangleBaseWidth = new Label();
            TrunkHeight = new Label();
            labelTrunkWidth = new Label();
            labelForY = new Label();
            labelForX = new Label();
            buttonMoveTree = new Button();
            buttonDrawTree = new Button();
            BackToMain = new Button();
            buttonClear = new Button();
            buttonRemoveTree = new Button();
            textBoxMoveY = new TextBox();
            textBoxMoveX = new TextBox();
            textBoxCircleRadius = new TextBox();
            textBoxTriangleHeight = new TextBox();
            textBoxTriangleBaseWidth = new TextBox();
            textBoxTrunkHeight = new TextBox();
            textBoxTrunkWidth = new TextBox();
            textBoxY = new TextBox();
            textBoxX = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxForChristmasTree).BeginInit();
            groupBoxTree.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBoxForChristmasTree
            // 
            pictureBoxForChristmasTree.Location = new Point(894, 12);
            pictureBoxForChristmasTree.Name = "pictureBoxForChristmasTree";
            pictureBoxForChristmasTree.Size = new Size(517, 543);
            pictureBoxForChristmasTree.TabIndex = 0;
            pictureBoxForChristmasTree.TabStop = false;
            pictureBoxForChristmasTree.MouseClick += PictureBox1_MouseClick;
            // 
            // groupBoxTree
            // 
            groupBoxTree.Controls.Add(labelCircleRadius);
            groupBoxTree.Controls.Add(labelMoveY);
            groupBoxTree.Controls.Add(labelMoveX);
            groupBoxTree.Controls.Add(labelTriangleHeight);
            groupBoxTree.Controls.Add(labelriangleBaseWidth);
            groupBoxTree.Controls.Add(TrunkHeight);
            groupBoxTree.Controls.Add(labelTrunkWidth);
            groupBoxTree.Controls.Add(labelForY);
            groupBoxTree.Controls.Add(labelForX);
            groupBoxTree.Controls.Add(buttonMoveTree);
            groupBoxTree.Controls.Add(buttonDrawTree);
            groupBoxTree.Controls.Add(BackToMain);
            groupBoxTree.Controls.Add(buttonClear);
            groupBoxTree.Controls.Add(buttonRemoveTree);
            groupBoxTree.Controls.Add(textBoxMoveY);
            groupBoxTree.Controls.Add(textBoxMoveX);
            groupBoxTree.Controls.Add(textBoxCircleRadius);
            groupBoxTree.Controls.Add(textBoxTriangleHeight);
            groupBoxTree.Controls.Add(textBoxTriangleBaseWidth);
            groupBoxTree.Controls.Add(textBoxTrunkHeight);
            groupBoxTree.Controls.Add(textBoxTrunkWidth);
            groupBoxTree.Controls.Add(textBoxY);
            groupBoxTree.Controls.Add(textBoxX);
            groupBoxTree.Font = new Font("Microsoft JhengHei", 9F);
            groupBoxTree.Location = new Point(12, 12);
            groupBoxTree.Name = "groupBoxTree";
            groupBoxTree.Size = new Size(876, 543);
            groupBoxTree.TabIndex = 1;
            groupBoxTree.TabStop = false;
            groupBoxTree.Text = "рисуем страдаем елочку";
            // 
            // labelCircleRadius
            // 
            labelCircleRadius.AutoSize = true;
            labelCircleRadius.Location = new Point(11, 331);
            labelCircleRadius.Name = "labelCircleRadius";
            labelCircleRadius.Size = new Size(100, 19);
            labelCircleRadius.TabIndex = 36;
            labelCircleRadius.Text = "Радиус круга";
            // 
            // labelMoveY
            // 
            labelMoveY.AutoSize = true;
            labelMoveY.Location = new Point(375, 191);
            labelMoveY.Name = "labelMoveY";
            labelMoveY.Size = new Size(245, 19);
            labelMoveY.TabIndex = 35;
            labelMoveY.Text = "Введите новую координату для Y:";
            // 
            // labelMoveX
            // 
            labelMoveX.AutoSize = true;
            labelMoveX.Location = new Point(375, 162);
            labelMoveX.Name = "labelMoveX";
            labelMoveX.Size = new Size(246, 19);
            labelMoveX.TabIndex = 34;
            labelMoveX.Text = "Введите новую координату для X:";
            // 
            // labelTriangleHeight
            // 
            labelTriangleHeight.AutoSize = true;
            labelTriangleHeight.Location = new Point(11, 281);
            labelTriangleHeight.Name = "labelTriangleHeight";
            labelTriangleHeight.Size = new Size(169, 19);
            labelTriangleHeight.TabIndex = 33;
            labelTriangleHeight.Text = "Высота треугольников";
            // 
            // labelriangleBaseWidth
            // 
            labelriangleBaseWidth.AutoSize = true;
            labelriangleBaseWidth.Location = new Point(6, 251);
            labelriangleBaseWidth.Name = "labelriangleBaseWidth";
            labelriangleBaseWidth.Size = new Size(247, 19);
            labelriangleBaseWidth.TabIndex = 32;
            labelriangleBaseWidth.Text = "Ширина основания треугольников";
            // 
            // TrunkHeight
            // 
            TrunkHeight.AutoSize = true;
            TrunkHeight.Location = new Point(11, 188);
            TrunkHeight.Name = "TrunkHeight";
            TrunkHeight.Size = new Size(107, 19);
            TrunkHeight.TabIndex = 31;
            TrunkHeight.Text = "Длина ствола";
            // 
            // labelTrunkWidth
            // 
            labelTrunkWidth.AutoSize = true;
            labelTrunkWidth.Location = new Point(11, 158);
            labelTrunkWidth.Name = "labelTrunkWidth";
            labelTrunkWidth.Size = new Size(115, 19);
            labelTrunkWidth.TabIndex = 30;
            labelTrunkWidth.Text = "Ширина ствола";
            // 
            // labelForY
            // 
            labelForY.AutoSize = true;
            labelForY.Location = new Point(11, 84);
            labelForY.Name = "labelForY";
            labelForY.Size = new Size(198, 19);
            labelForY.TabIndex = 29;
            labelForY.Text = "Введите координату для Y:";
            // 
            // labelForX
            // 
            labelForX.AutoSize = true;
            labelForX.Location = new Point(11, 54);
            labelForX.Name = "labelForX";
            labelForX.Size = new Size(199, 19);
            labelForX.TabIndex = 28;
            labelForX.Text = "Введите координату для X:";
            // 
            // buttonMoveTree
            // 
            buttonMoveTree.Location = new Point(551, 65);
            buttonMoveTree.Name = "buttonMoveTree";
            buttonMoveTree.Size = new Size(198, 64);
            buttonMoveTree.TabIndex = 27;
            buttonMoveTree.Text = "двигаем ёлку";
            buttonMoveTree.UseVisualStyleBackColor = true;
            buttonMoveTree.Click += ButtonMoveTree_Click;
            // 
            // buttonDrawTree
            // 
            buttonDrawTree.Location = new Point(30, 375);
            buttonDrawTree.Name = "buttonDrawTree";
            buttonDrawTree.Size = new Size(198, 64);
            buttonDrawTree.TabIndex = 26;
            buttonDrawTree.Text = "рисуем ёлку";
            buttonDrawTree.UseVisualStyleBackColor = true;
            buttonDrawTree.Click += ButtonDrawTree_Click;
            // 
            // BackToMain
            // 
            BackToMain.BackColor = Color.FromArgb(192, 192, 255);
            BackToMain.Location = new Point(11, 493);
            BackToMain.Margin = new Padding(3, 4, 3, 4);
            BackToMain.Name = "BackToMain";
            BackToMain.Size = new Size(278, 39);
            BackToMain.TabIndex = 25;
            BackToMain.Text = "Вернуться в главное меню";
            BackToMain.UseVisualStyleBackColor = false;
            BackToMain.Click += BackToMain_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(571, 498);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(295, 29);
            buttonClear.TabIndex = 24;
            buttonClear.Text = "Удалить все фигуры";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += ButtonClear_Click;
            // 
            // buttonRemoveTree
            // 
            buttonRemoveTree.Location = new Point(628, 463);
            buttonRemoveTree.Name = "buttonRemoveTree";
            buttonRemoveTree.Size = new Size(242, 29);
            buttonRemoveTree.TabIndex = 23;
            buttonRemoveTree.Text = "Удалить фигуру";
            buttonRemoveTree.UseVisualStyleBackColor = true;
            buttonRemoveTree.Click += ButtonRemoveTree_Click;
            // 
            // textBoxMoveY
            // 
            textBoxMoveY.Location = new Point(624, 188);
            textBoxMoveY.Name = "textBoxMoveY";
            textBoxMoveY.Size = new Size(125, 27);
            textBoxMoveY.TabIndex = 8;
            // 
            // textBoxMoveX
            // 
            textBoxMoveX.Location = new Point(624, 155);
            textBoxMoveX.Name = "textBoxMoveX";
            textBoxMoveX.Size = new Size(125, 27);
            textBoxMoveX.TabIndex = 7;
            // 
            // textBoxCircleRadius
            // 
            textBoxCircleRadius.Location = new Point(224, 324);
            textBoxCircleRadius.Name = "textBoxCircleRadius";
            textBoxCircleRadius.Size = new Size(125, 27);
            textBoxCircleRadius.TabIndex = 6;
            // 
            // textBoxTriangleHeight
            // 
            textBoxTriangleHeight.Location = new Point(224, 281);
            textBoxTriangleHeight.Name = "textBoxTriangleHeight";
            textBoxTriangleHeight.Size = new Size(125, 27);
            textBoxTriangleHeight.TabIndex = 5;
            // 
            // textBoxTriangleBaseWidth
            // 
            textBoxTriangleBaseWidth.Location = new Point(266, 248);
            textBoxTriangleBaseWidth.Name = "textBoxTriangleBaseWidth";
            textBoxTriangleBaseWidth.Size = new Size(125, 27);
            textBoxTriangleBaseWidth.TabIndex = 4;
            // 
            // textBoxTrunkHeight
            // 
            textBoxTrunkHeight.Location = new Point(224, 188);
            textBoxTrunkHeight.Name = "textBoxTrunkHeight";
            textBoxTrunkHeight.Size = new Size(125, 27);
            textBoxTrunkHeight.TabIndex = 3;
            // 
            // textBoxTrunkWidth
            // 
            textBoxTrunkWidth.Location = new Point(224, 155);
            textBoxTrunkWidth.Name = "textBoxTrunkWidth";
            textBoxTrunkWidth.Size = new Size(125, 27);
            textBoxTrunkWidth.TabIndex = 2;
            // 
            // textBoxY
            // 
            textBoxY.Location = new Point(224, 84);
            textBoxY.Name = "textBoxY";
            textBoxY.Size = new Size(125, 27);
            textBoxY.TabIndex = 1;
            // 
            // textBoxX
            // 
            textBoxX.Location = new Point(224, 51);
            textBoxX.Name = "textBoxX";
            textBoxX.Size = new Size(125, 27);
            textBoxX.TabIndex = 0;
            // 
            // ChristmasTree
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1423, 567);
            Controls.Add(groupBoxTree);
            Controls.Add(pictureBoxForChristmasTree);
            Name = "ChristmasTree";
            Text = "ChristmasTree";
            Load += ChristmasTree_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxForChristmasTree).EndInit();
            groupBoxTree.ResumeLayout(false);
            groupBoxTree.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBoxForChristmasTree;
        private GroupBox groupBoxTree;
        private TextBox textBoxMoveY;
        private TextBox textBoxMoveX;
        private TextBox textBoxCircleRadius;
        private TextBox textBoxTriangleHeight;
        private TextBox textBoxTriangleBaseWidth;
        private TextBox textBoxTrunkHeight;
        private TextBox textBoxTrunkWidth;
        private TextBox textBoxY;
        private TextBox textBoxX;
        private Button buttonMoveTree;
        private Button buttonDrawTree;
        private Button BackToMain;
        private Button buttonClear;
        private Button buttonRemoveTree;
        private Label labelCircleRadius;
        private Label labelMoveY;
        private Label labelMoveX;
        private Label labelTriangleHeight;
        private Label labelriangleBaseWidth;
        private Label TrunkHeight;
        private Label labelTrunkWidth;
        private Label labelForY;
        private Label labelForX;
    }
}