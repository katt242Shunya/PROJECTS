﻿namespace _8labb
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ToDrawRectangle = new Button();
            ToDrawSquare = new Button();
            ToDrawEllipse = new Button();
            ToDrawCircle = new Button();
            ToDrawTree = new Button();
            label1 = new Label();
            ToDrawTriangle = new Button();
            ToDrawPolygon = new Button();
            SuspendLayout();
            // 
            // ToDrawRectangle
            // 
            ToDrawRectangle.BackColor = Color.LightBlue;
            ToDrawRectangle.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawRectangle.Location = new Point(77, 144);
            ToDrawRectangle.Margin = new Padding(3, 4, 3, 4);
            ToDrawRectangle.Name = "ToDrawRectangle";
            ToDrawRectangle.Size = new Size(269, 68);
            ToDrawRectangle.TabIndex = 0;
            ToDrawRectangle.Text = "нарисовать прямоугольник";
            ToDrawRectangle.UseVisualStyleBackColor = false;
            ToDrawRectangle.Click += ToDrawRectangle_Click;
            // 
            // ToDrawSquare
            // 
            ToDrawSquare.BackColor = Color.LightBlue;
            ToDrawSquare.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawSquare.Location = new Point(77, 244);
            ToDrawSquare.Margin = new Padding(3, 4, 3, 4);
            ToDrawSquare.Name = "ToDrawSquare";
            ToDrawSquare.Size = new Size(269, 68);
            ToDrawSquare.TabIndex = 1;
            ToDrawSquare.Text = "нарисовать квадрат";
            ToDrawSquare.UseVisualStyleBackColor = false;
            ToDrawSquare.Click += ToDrawSquare_Click;
            // 
            // ToDrawEllipse
            // 
            ToDrawEllipse.BackColor = Color.LavenderBlush;
            ToDrawEllipse.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawEllipse.Location = new Point(77, 436);
            ToDrawEllipse.Margin = new Padding(3, 4, 3, 4);
            ToDrawEllipse.Name = "ToDrawEllipse";
            ToDrawEllipse.Size = new Size(269, 68);
            ToDrawEllipse.TabIndex = 2;
            ToDrawEllipse.Text = "нарисовать эллипс";
            ToDrawEllipse.UseVisualStyleBackColor = false;
            ToDrawEllipse.Click += ToDrawEllipse_Click;
            // 
            // ToDrawCircle
            // 
            ToDrawCircle.BackColor = Color.LavenderBlush;
            ToDrawCircle.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawCircle.Location = new Point(77, 535);
            ToDrawCircle.Margin = new Padding(3, 4, 3, 4);
            ToDrawCircle.Name = "ToDrawCircle";
            ToDrawCircle.Size = new Size(269, 68);
            ToDrawCircle.TabIndex = 3;
            ToDrawCircle.Text = "нарисовать круг";
            ToDrawCircle.UseVisualStyleBackColor = false;
            ToDrawCircle.Click += ToDrawCircle_Click;
            // 
            // ToDrawTree
            // 
            ToDrawTree.BackColor = Color.Honeydew;
            ToDrawTree.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawTree.Location = new Point(547, 480);
            ToDrawTree.Margin = new Padding(3, 4, 3, 4);
            ToDrawTree.Name = "ToDrawTree";
            ToDrawTree.Size = new Size(269, 68);
            ToDrawTree.TabIndex = 4;
            ToDrawTree.Text = "нарисовать ёлку";
            ToDrawTree.UseVisualStyleBackColor = false;
            ToDrawTree.Click += ToDrawTree_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label1.Location = new Point(45, 52);
            label1.Name = "label1";
            label1.Size = new Size(407, 32);
            label1.TabIndex = 5;
            label1.Text = "Будем рисовать разные фигурки!";
            // 
            // ToDrawTriangle
            // 
            ToDrawTriangle.BackColor = Color.RosyBrown;
            ToDrawTriangle.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawTriangle.Location = new Point(547, 144);
            ToDrawTriangle.Margin = new Padding(3, 4, 3, 4);
            ToDrawTriangle.Name = "ToDrawTriangle";
            ToDrawTriangle.Size = new Size(269, 68);
            ToDrawTriangle.TabIndex = 6;
            ToDrawTriangle.Text = "нарисовать тругольник";
            ToDrawTriangle.UseVisualStyleBackColor = false;
            ToDrawTriangle.Click += ToDrawTriangle_Click;
            // 
            // ToDrawPolygon
            // 
            ToDrawPolygon.BackColor = Color.RosyBrown;
            ToDrawPolygon.Font = new Font("Microsoft JhengHei", 9F);
            ToDrawPolygon.Location = new Point(547, 244);
            ToDrawPolygon.Margin = new Padding(3, 4, 3, 4);
            ToDrawPolygon.Name = "ToDrawPolygon";
            ToDrawPolygon.Size = new Size(269, 68);
            ToDrawPolygon.TabIndex = 7;
            ToDrawPolygon.Text = "нарисовать многоугольник";
            ToDrawPolygon.UseVisualStyleBackColor = false;
            ToDrawPolygon.Click += ToDrawPolygon_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1165, 787);
            Controls.Add(ToDrawPolygon);
            Controls.Add(ToDrawTriangle);
            Controls.Add(label1);
            Controls.Add(ToDrawTree);
            Controls.Add(ToDrawCircle);
            Controls.Add(ToDrawEllipse);
            Controls.Add(ToDrawSquare);
            Controls.Add(ToDrawRectangle);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Main";
            Text = "Main";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button ToDrawRectangle;
        private Button ToDrawSquare;
        private Button ToDrawEllipse;
        private Button ToDrawCircle;
        private Button ToDrawTree;
        private Label label1;
        private Button ToDrawTriangle;
        private Button ToDrawPolygon;
    }
}