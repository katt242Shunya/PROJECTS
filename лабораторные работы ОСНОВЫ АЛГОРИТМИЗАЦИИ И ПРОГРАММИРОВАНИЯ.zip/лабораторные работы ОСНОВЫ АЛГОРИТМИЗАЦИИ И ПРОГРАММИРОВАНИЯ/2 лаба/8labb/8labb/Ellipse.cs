﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLib;
using static _8labb.Ellipse;

namespace _8labb
{
    public partial class Ellipse : Form
    {
        private EllipseFigure currentEllipse = null;

        public Ellipse()
        {
            InitializeComponent();
            pictureBoxForEllipse.MouseClick += PictureBox1_MouseClick;

        }

        private void Ellipse_Load(object sender, EventArgs e)
        {
            Init.Initialize(pictureBoxForEllipse, pictureBoxForEllipse.Width, pictureBoxForEllipse.Height);
            Init.ClearBitmap();
        }

        private void buttonDrawEllipse_Click(object sender, EventArgs e)
        {
            int x, y, radiusWidth, radiusHeight;

            if (textBoxEllipseX.Text.Length > 3 || textBoxEllipseY.Text.Length > 3 || textBoxRadiusWidth.Text.Length > 3 || textBoxRadiusHeight.Text.Length > 3)
            {
                MessageBox.Show("Введите не более трех символов");
                return;
            }

            try
            {
                x = int.Parse(textBoxEllipseX.Text);
                y = int.Parse(textBoxEllipseY.Text);
                radiusWidth = int.Parse(textBoxRadiusWidth.Text);
                radiusHeight = int.Parse(textBoxRadiusHeight.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка ввода: введите число");
                return;
            }

            if (x < 0 || y < 0 || radiusWidth < 0 || radiusHeight < 0)
            {
                MessageBox.Show("Значение не может быть отрицательным");
                return;
            }

            if (x + radiusWidth * 2 > Init.pictureBoxWidth || y + radiusHeight * 2 > Init.pictureBoxHeight)
            {
                MessageBox.Show("Эллипс выходит за границы");
                return;
            }

            EllipseFigure ellipse = new EllipseFigure(x, y, radiusWidth, radiusHeight);
            ShapeContainer.AddFigure(ellipse);
            RedrawAll();

            currentEllipse = ellipse;

            textBoxEllipseX.Text = "";
            textBoxEllipseY.Text = "";
            textBoxRadiusWidth.Text = "";
            textBoxRadiusHeight.Text = "";
        }

        private void RedrawAll()
        {
            Init.ClearBitmap();
            using (Graphics g = Graphics.FromImage(Init.bitmap))
            {
                ShapeContainer.DrawAll(g);
            }
            Init.UpdatePictureBox();
        }

        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (var figure in ShapeContainer.figureList)
            {
                figure.IsSelected = false;
            }

            for (int i = ShapeContainer.figureList.Count - 1; i >= 0; i--)
            {
                FigureClass figure = ShapeContainer.figureList[i];
                if (figure is EllipseFigure ellipse && ellipse.Contains(e.X, e.Y))
                {
                    currentEllipse = ellipse;
                    currentEllipse.IsSelected = true;
                    RedrawAll();
                    return;
                }
            }
            currentEllipse = null;
            RedrawAll();
        }

        private void buttonMoveEllipse_Click(object sender, EventArgs e)
        {
            int moveX, moveY;

            if (currentEllipse == null)
            {
                MessageBox.Show("Сначала выберите эллипс");
                return;
            }
            try
            {
                moveX = int.Parse(textBoxMoveX.Text); 
                moveY = int.Parse(textBoxMoveY.Text); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный ввод чисел");
                return;
            }
            int newX = currentEllipse.x + moveX; 
            int newY = currentEllipse.y + moveY;

            int ellipseLeft = newX;
            int ellipseTop = newY;
            int ellipseRight = newX + currentEllipse.RadiusWidth * 2;
            int ellipseBottom = newY + currentEllipse.RadiusHeight * 2;

            if (ellipseLeft < 0)
            {
                newX = 0;
            }
            else if (ellipseRight > Init.pictureBoxWidth)
            {
                newX = Init.pictureBoxWidth - currentEllipse.RadiusWidth * 2;
            }

            if (ellipseTop < 0)
            {
                newY = 0;
            }
            else if (ellipseBottom > Init.pictureBoxHeight)
            {
                newY = Init.pictureBoxHeight - currentEllipse.RadiusHeight * 2;
            }
            ellipseLeft = newX;
            ellipseTop = newY;
            ellipseRight = newX + currentEllipse.RadiusWidth * 2;
            ellipseBottom = newY + currentEllipse.RadiusHeight * 2;

            if ((moveX < 0 && ellipseLeft == 0) || (moveX > 0 && ellipseRight == Init.pictureBoxWidth) || (moveY < 0 && ellipseTop == 0) || (moveY > 0 && ellipseBottom == Init.pictureBoxHeight))
            {
                MessageBox.Show("Перемещение больше недоступно эллипс достиг границы");
                return;
            }

            currentEllipse.MoveTo(newX, newY);
            currentEllipse.x = newX;
            currentEllipse.y = newY;

            RedrawAll();
        }

        private void buttonResizeEllipse_Click(object sender, EventArgs e)
        {
            int deltaRadiusWidth, deltaRadiusHeight;

            if (currentEllipse == null)
            {
                MessageBox.Show("Сначала выберите эллипс");
                return;
            }

            try
            {
                deltaRadiusWidth = int.Parse(textBoxResizeRadiusWidth.Text); 
                deltaRadiusHeight = int.Parse(textBoxResizeRadiusHeight.Text); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный ввод числа");
                return;
            }
            int newRadiusWidth = currentEllipse.RadiusWidth + deltaRadiusWidth; 
            int newRadiusHeight = currentEllipse.RadiusHeight + deltaRadiusHeight; 

            if (newRadiusWidth < 0 || newRadiusHeight < 0)
            {
                MessageBox.Show("Радиусы не могут быть отрицательными");
                return;
            }

            int maxRadiusWidth = (Init.pictureBoxWidth - currentEllipse.x) / 2;  
            int maxRadiusHeight = (Init.pictureBoxHeight - currentEllipse.y) / 2; 

            if (newRadiusWidth > maxRadiusWidth)
            {
                newRadiusWidth = maxRadiusWidth;
                MessageBox.Show("Радиус по X уменьшен до максимально возможного значения");
            }

            if (newRadiusHeight > maxRadiusHeight)
            {
                newRadiusHeight = maxRadiusHeight;
                MessageBox.Show("Радиус по Y уменьшен до максимально возможного значения");
            }

            currentEllipse.Resize(newRadiusWidth, newRadiusHeight);

            RedrawAll();

        }

        private void buttonRemoveEllipse_Click(object sender, EventArgs e)
        {
            if (currentEllipse == null)
            {
                MessageBox.Show("Сначала выберите эллипс");
                return;
            }

            ShapeContainer.RemoveFigure(currentEllipse);
            currentEllipse = null;
            RedrawAll();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            currentEllipse = null;
            Init.ClearBitmap();
        }

        private void BackToMain_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();

            Main main = new Main();
            main.Show();
            Hide();
        }
    }
}
