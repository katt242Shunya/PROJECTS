﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLib;
using static _8labb.Square;

namespace _8labb
{


    public partial class Square : Form  
    {
        private SquareFigure currentSquare = null;

        public Square()
        {
            InitializeComponent();
            pictureBoxForSquare.MouseClick += PictureBox1_MouseClick;

        }

        private void Square_Load(object sender, EventArgs e)
        {
            Init.Initialize(pictureBoxForSquare, pictureBoxForSquare.Width, pictureBoxForSquare.Height);
            Init.ClearBitmap();
        }

        private void buttonDrawSquare_Click(object sender, EventArgs e)
        {
            //Init.ClearBitmap();
            int x, y, side;

            if (textBoxSquareX.Text.Length > 3)
            {
                MessageBox.Show("сторона слишком длинная");
                return;
            }
            if (textBoxSquareY.Text.Length > 3)
            {
                MessageBox.Show("сторона слишком длинная");
                return;
            }
            if (textBoxSide.Text.Length > 3)
            {
                MessageBox.Show("сторона слишком длинная");
                return;
            }

            try
            {
                x = int.Parse(textBoxSquareX.Text);
                y = int.Parse(textBoxSquareY.Text);
                side = int.Parse(textBoxSide.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("ошибка ввода введите число");
                return;
            }

            if (x < 0 || y < 0 || side < 0)
            {
                MessageBox.Show("не должно быть отрицательным");
                return;
            }

            if (x + side > Init.pictureBoxWidth || y + side > Init.pictureBoxHeight)
            {
                MessageBox.Show("квадрат выходит за границы");
                return;
            }

            Init.ClearBitmap();
            SquareFigure square = new SquareFigure(x, y, side);
            ShapeContainer.AddFigure(square);
            RedrawAll();
            currentSquare = square;

            textBoxSquareX.Text = "";
            textBoxSquareY.Text = "";
            textBoxSide.Text = "";
        }

        private void RedrawAll()
        {
            Init.ClearBitmap();
            using (Graphics g = Graphics.FromImage(Init.bitmap))
            {
                ShapeContainer.DrawAll(g);
            }
            Init.UpdatePictureBox();
        }

        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (var figure in ShapeContainer.figureList)
            {
                figure.IsSelected = false;
            }

            for (int i = ShapeContainer.figureList.Count - 1; i >= 0; i--)
            {
                FigureClass figure = ShapeContainer.figureList[i];
                if (figure is SquareFigure sq && sq.Contains(e.X, e.Y))
                {
                    currentSquare = sq;
                    currentSquare.IsSelected = true;
                    RedrawAll();
                    return;
                }
            }
            currentSquare = null;
            RedrawAll();
        }

        private void buttonMoveSquare_Click(object sender, EventArgs e)
        {
            int moveX, moveY;

            if (currentSquare == null)
            {
                MessageBox.Show("Сначала выберите квадрат");
                return;
            }

            try
            {
                moveX = int.Parse(textBoxMoveX.Text); 
                moveY = int.Parse(textBoxMoveY.Text); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный ввод чисел");
                return;
            }
            int newX = currentSquare.x + moveX; 
            int newY = currentSquare.y + moveY; 

            bool isOutOfBoundsX = false; 
            bool isOutOfBoundsY = false; 

            if (newX < 0) 
            {
                newX = 0; 
                isOutOfBoundsX = true;  
            }
            else if (newX + currentSquare.w > Init.pictureBoxWidth) 
            {
                newX = Init.pictureBoxWidth - currentSquare.w; 
                isOutOfBoundsX = true; 
            }

            if (newY < 0) 
            {
                newY = 0; 
                isOutOfBoundsY = true; 
            }
            else if (newY + currentSquare.h > Init.pictureBoxHeight) 
            {
                newY = Init.pictureBoxHeight - currentSquare.h; 
                isOutOfBoundsY = true; 
            }
            if ((isOutOfBoundsX && moveX != 0) || (isOutOfBoundsY && moveY != 0))
            {
                MessageBox.Show("перемещение больше недоступно");
                return;
            }
            currentSquare.MoveTo(newX, newY);

            RedrawAll();
        }

        private void buttonResizeSquare_Click(object sender, EventArgs e)
        {
            int deltaSide;

            if (currentSquare == null)
            {
                MessageBox.Show("Сначала выберите квадрат");
                return;
            }

            try
            {
                deltaSide = int.Parse(textBoxResizeSide.Text); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный ввод числа");
                return;
            }
            int newSide = currentSquare.w + deltaSide; 

            if (newSide < 0)
            {
                MessageBox.Show("Сторона не может быть отрицательной");
                return;
            }
            int maxSideX = Init.pictureBoxWidth - currentSquare.x;  
            int maxSideY = Init.pictureBoxHeight - currentSquare.y; 
            int maxSide = Math.Min(maxSideX, maxSideY); 

            if (newSide > maxSide)
            {
                newSide = maxSide;
                MessageBox.Show("Сторона уменьшена до максимально возможного значения");
            }

            currentSquare.Resize(newSide, newSide);

            RedrawAll();

        }

        private void buttonRemoveSquare_Click(object sender, EventArgs e)
        {
            if (currentSquare == null)
            {
                MessageBox.Show("сначала выберите квадрат");
                return;
            }

            ShapeContainer.RemoveFigure(currentSquare);
            currentSquare = null;
            RedrawAll();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            currentSquare = null;
            Init.ClearBitmap();
        }

        

        private void BackToMain_Click(object sender, EventArgs e)
        {
            ShapeContainer.figureList.Clear();
            Init.ClearBitmap();

            Main main = new Main();
            main.Show();
            Hide();
        }
    }
}
